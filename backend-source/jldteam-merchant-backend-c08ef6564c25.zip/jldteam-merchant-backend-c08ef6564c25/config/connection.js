const development = {
    database: 'couponTalkTalk_k',
    username: 'root',
    password: '',
    host: 'localhost',
    dialect: 'mysql',

};

const testing = {
    database: 'couponTalkTalk_k',
    username: 'cttk',
    password: 'pJ9UXkW$S5HMF',
    host: 'localhost',
    dialect: 'mysql',
};



const production = {
    database: 'couponTalkTalk_k',
    username: 'cttk_prod',
    password: '6TP4WG6(TAK{e[JA@1314',
    host: 'ctt-korea-version.cfbqx7bmlxde.ap-northeast-2.rds.amazonaws.com',
    dialect: 'mysql',
};





module.exports = {
    development,
    testing,
    production,
};