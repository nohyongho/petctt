const Sequelize = require('sequelize');
const connection = require('./connection');

let database;

switch (process.env.NODE_ENV) {
    case 'production':
        database = new Sequelize(
            connection.production.database,
            connection.production.username,
            connection.production.password, {
                logging: false,
                host: connection.production.host,
                dialect: connection.production.dialect,
                pool: {
                    max: 5,
                    min: 0,
                    idle: 10000,
                },
                dialectOptions: {
                    dateStrings: true,
                    typeCast: function(field, next) { // for reading from database
                        if (field.type === 'DATETIME') {
                            return field.string()
                        }
                        return next()
                    },
                },
                "timezone": "+09:00" //for writing to database
            });
        break;
    case 'testing':
        database = new Sequelize(
            connection.testing.database,
            connection.testing.username,
            connection.testing.password, {
                logging: false,

                host: connection.testing.host,
                dialect: connection.testing.dialect,
                pool: {
                    max: 5,
                    min: 0,
                    idle: 10000,
                },
                dialectOptions: {
                    dateStrings: true,
                    typeCast: function(field, next) { // for reading from database
                        if (field.type === 'DATETIME') {
                            return field.string()
                        }
                        return next()
                    },
                },
                "timezone": "+09:00" //for writing to database
            });
        break;
    default:
        database = new Sequelize(
            connection.development.database,
            connection.development.username,
            connection.development.password, {
                logging: false,
                host: connection.development.host,
                dialect: connection.development.dialect,
                pool: {
                    max: 5,
                    min: 0,
                    idle: 10000,
                },
                dialectOptions: {
                    dateStrings: true,
                    typeCast: function(field, next) { // for reading from database
                        if (field.type === 'DATETIME') {
                            return field.string()
                        }
                        return next()
                    },
                },
                "timezone": "+09:00" //for writing to database
            });
}

module.exports = database;