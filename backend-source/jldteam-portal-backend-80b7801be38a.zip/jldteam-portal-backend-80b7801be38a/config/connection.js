const testing = {
    database: 'coupontalktalk_kr',
    username: 'root',
    password: '12345678',
    host: '127.0.0.1',
    dialect: 'mysql',
};
const development  = {
    database: 'couponTalkTalk_k',
    username: 'cttk',
    password: 'pJ9UXkW$S5HMF',
    host: 'localhost',
    dialect: 'mysql',
};

// const production = {
//     database: 'couponTalkTalk_k',
//     username: 'cttk_prod',
//     password: '6TP4WG6(TAK{e[JA@1314',
//     host: 'ctt-korea-version.cfbqx7bmlxde.ap-northeast-2.rds.amazonaws.com',
//     dialect: 'mysql',
// }; 


const production = {
    database: 'kouponlee_dev',
    username: 'kouponlee_dev',
    password: 'kouponly_dev@1314',
    host: '127.0.0.1',
    dialect: 'mysql',
};

module.exports = {
    development,
    testing,
    production,
};