const usersRouter = require('../routes/users');
const authRouter = require('../routes/auth');
const couponRouter = require('../routes/coupon');
const commonRouter = require('../routes/common');
const campaignRouter = require('../routes/campaign');
const outletRouter = require('../routes/outlet');
const graphRouter = require('../routes/graph');
const productsRouter = require('../routes/products');
const orderRouter = require('../routes/order');
const adsRouter = require('../routes/ads');
const transactionsRouter = require('../routes/transactions');
const walletsRouter = require('../routes/wallets');





module.exports = {
    usersRouter,
    authRouter,
    couponRouter,
    commonRouter,
    campaignRouter,
    outletRouter,
    graphRouter,
    productsRouter,
    orderRouter,
    adsRouter,
    transactionsRouter,
    walletsRouter,
    host: 'http://127.0.0.1',
    port: '3000',

    migrate: false
};
//088553109975