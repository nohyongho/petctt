module.exports = Object.freeze({
    
    /**Auth Constant Messages */
    SESSION_EXPIRED:'Your session has been expired please login again.',
    NEW_USER_CREATED:'Account has been created successfully,Now you can login by verifying your email.',
    LOGIN_SUCCESS:'Successfully login',
    LOGOUT_SUCCESS:'Successfully logout',
    ALREADY_REGISTERED:'You are already registered with this email or contact number in Coupon TalkTalk.',
    INVALID_USER:'You are not registered with coupon talktalk.',
    EMAIL_NOT_VERIFIED:'Your email is not verified',
    BRAND_UNIQUE:'Brand name already exist it should be unique',
    BRAND_CREATED:'Brand created successfully',
    INVALID_CREDENTIALS:'Provided credentials are incorrect, please try again.',
    USER_BLOCKED:'User is blocked by admin.',
    VERIFY_EMAIL_SUCCESS:'Your email has been verified, now you can use your app.',
    LINK_EXPIRED:'Your verification has been expired. Try again by sending new verification link.',
    ALREADY_VERIFIED:'You are already verified your Coupon Talk Talk account.\n Now You can login to the app.\n Thank You !',
    WRONG_CODE:'Verification code is wrong.',
    PASSWORDS_NOMATCH: 'Password and Confirm password do not match',
    EXPIRED_CODE:'Verification code is Expire please send new code.',
    RESET_PASSWORD_SUCCESS:'Your password has been changed successfully.',
    RESET_PASSWORD_ERROR:'Unable to update password, internal server error.',
    OUTLET_USER_SUCCESS:'Outlet User account has been created successfully against given email.',
    WRONG_OLD_PASSWORD: 'You enter wrong old password. \n Please insert correct old password.',
    CODE_SENT: 'Verification code sent to your registered email.',

    /**Users Constant Messages */
    USER_UPDATED:'User updated successfully.',
    USER_DELETED:'User deleted successfully.',
    
    /**Coupons Constant Messages */
    COUPON_CREATED:'Coupon created successfully.',
    COUPON_UPDATED:'Coupon updated successfully.',
    COUPON_DELETED:'COUPON removed successfully',
    COLLECTED_COUPON_SUCCESS:'Coupon collected successfully.',
    COLLECTED_LIMIT:'Sorry coupon collect limit is over.',
    COUPON_NOTFOUND:'Sorry No Coupon found',
    INVALID:'Invalid data.',

    /**Brand Constant Messages */
    BRAND_NOTFOUND:'Sorry No brand found against this merchant',
    BRAND_DELETED:'Brand removed successfully',

    /**Product Constant Messages */
    PRODUCT_CREATED:'Product created successfully.',
    PRODUCT_UPDATED:'Product updated successfully.',
    PRODUCT_DELETED:'Product removed successfully',
    PRODUCT_NOTFOUND:'Sorry No Product found',

    /**Product Types Constant Messages */
    PRODUCT_TYPE_CREATED:'Product type created successfully.',
    PRODUCT_TYPE_UPDATED:'Product type updated successfully.',
    PRODUCT_TYPE_DELETED:'Product type removed successfully',
    PRODUCT_TYPE_NOTFOUND:'Sorry No Product type found',

    /**Category Constant Messages */
    CATEGORY_CREATED:'Category created successfully.',
    CATEGORY_UPDATED:'Category updated successfully.',
    CATEGORY_DELETED:'Category removed successfully',
    CATEGORY_NOTFOUND:'Sorry No Category found',

    /**Outlets Constant Messages */
    OUTLET_CREATED:'Outlet created successfully.',
    OUTLET_UPDATED:'Outlet updated successfully.',
    OUTLET_DELETED:'Outlet removed successfully',
    OUTLET_NOTFOUND:'Sorry No outlet found against this merchant',
    
    /**Orders Constant Messages */
    ORDER_CREATED:'Order created successfully.',
    ORDER_UPDATED:'Order updated successfully.',
    ORDER_DELETED:'Order removed successfully',
    ORDER_NOTFOUND:'Sorry No Order found against this merchant',
    ORDERS_NOTFOUND:'Sorry No Order found',

    /**Ads Constant Messages */
    ADS_CREATED:'Ad created successfully.',
    ADS_UPDATED:'Ad updated successfully.',
    ADS_DELETED:'Ad removed successfully',
    ADS_NOTFOUND:'Sorry No Ad found against this merchant',

    /**General Messages */
    SUCCESS:'success',
    UPDATE_VALUE: 'Value updated Successfully',
    SERVER_ERROR:'Internal server error.\nPlease try again or contact with our suport team.',
    NO_RECORD:'No record found',
    TRANSACTION_TYPE:'Transaction type is required',
    CURRENCY: 4,
 

});