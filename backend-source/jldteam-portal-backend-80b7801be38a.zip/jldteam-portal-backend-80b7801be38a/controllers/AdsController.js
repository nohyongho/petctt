/** Model */
const Ads = require('../models/Ads');
const  User =require('../models/User');
const Categories = require('../models/Categories');
/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/AdsValidator');
const UserSeenAds = require('../models/ArmUserSeenAds');
const ArmSeenAdsLocation = require('../models/ArmSeenAdsLocation');
const ArmRewardTxnCrypto = require('../models/ArmRewardTxnCrypto');
const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const Op = Sequelize.Op;


const AdsController = () => {

    /**get all Ads For Admin Portal  */
    const getAllAds = async (req, res) => {
        try {
            const validationResponse = validate.paginationBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let queryClause;
            let adsCount=0;
            switch (req.body.filterType) {
                case 'all':
                    adsCount = await Ads.count({where:{soft_delete: false}});
                    queryClause= { soft_delete: false };
                    break;
                case 'other':
                    if(req.body.status){
                        adsCount = await Ads.count({ where:{ adType: req.body.adsType, status: req.body.status, soft_delete: false}});
                        queryClause = {'adType': `${req.body.adsType}`, 'status': `${req.body.status}`, soft_delete: false };
                    }else{
                        adsCount = await Ads.count({ where:{ adType: req.body.adsType, soft_delete: false}});
                        queryClause = {'adType': `${req.body.adsType}`  ,soft_delete: false };
                    }
                    break;
                case 'status':
                    if(req.body.adsType){
                        adsCount = await Ads.count({ where:{ adType: req.body.adsType,status: req.body.status, soft_delete: false}});
                        queryClause = {'adType': `${req.body.adsType}`, 'status': `${req.body.status}`, soft_delete: false };
                    }else{
                        adsCount = await Ads.count({ where:{ status: req.body.status, soft_delete: false}});
                        queryClause = {'status': `${req.body.status}`, soft_delete: false };
                    }
                    break;
                default:
                    break;
            }
            let adsData = await
            Ads.findAll({
                include:[{ model: User, attributes:[['full_name','fullName']] }, {model: Categories, attributes:[['title','name']]}],
                    where: queryClause,
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
                if (adsData.length<1) {
                    return response.successDT(res, [],0,0);
                } 
                // var newData = [];
                // adsData.forEach(element => {
                //     newData.push({
                //         id: element.adId,
                //         cryptoTxnId:element.cryptoTxnId,
                //         repeatCount:element.repeatCount,
                //         totalSeenCount:element.totalSeenCount,
                //         budgetITC:element.budgetITC,
                //         remainingBudget:element.remainingBudget,
                //         perViewPrice:element.perViewPrice,
                //         title:element.title,
                //         detail:element.detail,
                //         link:element.link,
                //         imgUrl:element.imgUrl,
                //         videoUrl:element.videoUrl,
                //         adType:element.adType,
                //         status:element.status,
                //         availability:element.availability,
                //         isExternalLink:element.isExternalLink,
                //         createdAt:element.createdAt,
                //         category:element.category,
                //         userName:element.userName,
                //     });
                // });
                return response.successDT(res, constant.SUCCESS, adsData, adsCount, adsCount);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**search ads by title For Admin Portal  */
    const searchAds = async (req, res) => {
        try {
            
            const validationResponse = validate.searchBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let adsCount= 0;
            adsCount = await Ads.count({where:{soft_delete:false}})
            let adsData = await
            Ads.findAll({
                include:{ model: User },
                where: { title: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` },soft_delete:false }
                });
                if (adsData.length<1) {
                    return response.successDT(res, [],0,0);
                } 
               let newData= adsData.map(ads=>{
                    ads.userName = ads.User.full_name;
                    console.log("TESAFFDSAGFGDSFHJSGF:::", ads.User);
                    delete ads.User;
                    return ads;
                });
                return response.successDT(res, constant.SUCCESS, newData, adsCount, adsCount);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get Ads by id For Admin Portal  */
    const getAdDetail= async (req, res) => {
        try {
            let adsData = await
            Ads.findOne({
                include:[
                    { model: User, attributes:[['full_name','fullName']] },
                    { model: Categories, attributes:[['title','name']]},

                ],
                    where: { id: req.params.id, soft_delete: false }
                }); 
                if (!adsData) {
                    return response.success(res, constant.NO_RECORD, {} );
                } 
                return response.success(res, constant.SUCCESS, adsData);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get UserSeenAds by Ad Id */
    const userSeenAdByAdId = async(req,res)=>{
        try {

            const validationResponse = validate.seenAds(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }

            let userSeenAds = await UserSeenAds.findAll({
                where: { adId: req.body.adId },
                include: {model: User},
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if(!userSeenAds){
                return response.error(res, constant.NO_RECORD);
            }
            userSeenAds = userSeenAds.map(ele=>{
                return{
                    email: ele.User.email,
                    fullName: ele.User.full_name,
                    contactNo: ele.User.contact_no,
                    seenCount: ele.count,
                    lastSeen: ele.updatedAt
                }
            });

            return response.success(res, constant.SUCCESS, userSeenAds);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res,error.message);
        }
    }
    /**get Ads by id For Admin Portal  */
    const updateAdStatus = async (req, res) => {
        try {
            let updateRes = await
            Ads.update({ status: req.body.status },{where:{ id: req.params.id }} );
                if (!updateRes) {
                    return response.error(res, constant.SERVER_ERROR );
                } 
                return response.success(res, constant.ADS_UPDATED, req.body.status);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get Ads by id For Admin Portal  */
    const updatePercentage = async (req, res) => {
        try {
            let updateRes = await
            Ads.update({ perViewPrice: req.body.percentage/100 },{where:{ id: req.params.id }} );
            console.log("DELETE:::",updateRes);
                if (!updateRes) {
                    return response.error(res, constant.SERVER_ERROR );
                } 
                return response.success(res, constant.ADS_UPDATED, req.body.percentage/100);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get Ads by id For Admin Portal  */
    const deleteAd = async (req, res) => {
        try {
            let updateRes = await Ads.update({ softDelete: true },{ where:{ id: req.params.id } } );
            console.log("DELETE:::",updateRes);
            if (!updateRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res, constant.ADS_DELETED );

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    return {
        getAllAds,
        searchAds,
        getAdDetail,
        userSeenAdByAdId,
        updateAdStatus,
        updatePercentage,
        deleteAd
    };
};

module.exports = AdsController;