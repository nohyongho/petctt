/** Model */
const CountryList = require('../models/CountryList');
const Brand = require('../models/Brand');
const Outlet = require('../models/Outlet');
const Coupon = require('../models/Coupon');
const CollectedCoupons = require('../models/CollectedCoupon');
const MpCouponOutlet = require('../models/MpCouponOutlet');
const ProductType = require('../models/ProductType');
const CouponCode = require('../models/CouponCode');
const Currency = require('../models/Currency');
const Category = require('../models/Categories');
const State = require('../models/StateList');
const City = require('../models/CityList');
const User = require('../models/User');
const UserDetail = require('../models/UserDetail');
const Role = require('../models/Role');
const Products = require('../models/Products');
const Order = require('../models/Order');
const Coin = require('../models/Coin');
const GeneralConfig = require('../models/GeneralConfig');

/**Services  */
const uploadImage = require('../services/imageUpload.service');

/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/AuthValidator');
const validateCommon = require('../helper/validators/CommonValidator');

const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const Op = Sequelize.Op;

const CommonController = () => {
    /**get all countries list  */
    const getCountryList = async (req, res) => {
        const foundCountryList = await CountryList.findAll({
            attributes: ['id', ['country_name', 'name'], ['flag_image', 'image'], ['phone_code', 'phoneCode'], ['sort_name', 'sortName']]
        });

        if (!foundCountryList) {
            return response.recordNotFound(res, req);
        }
        return response.success(res, constant.SUCCESS, foundCountryList);
    };
    /**get sate list by given country id */
    const statesList = async (req, res) => {
        const countryId = req.params.countryId;
        try {
            let list = await State.findAll({ where: { country_id: countryId }, attributes: ['id', ['state_name', 'name']] });
            if (list) {
                return response.success(res, constant.SUCCESS, list);
            } else {
                return response.error(res, constant.NO_RECORD);
            }
        } catch (error) {
            return response.error(res, error.message);
        }
    };
    /**getching the cities list on the basis of country Id and state Id */
    const citiesList = async (req, res) => {
        //  const stateId = req.params.stateId;

        const countryId = req.params.countryId;
        try {
            let cityList = await City.findAll({ where: { country_id: countryId }, attributes: ['id', ['city_name', 'name']] });
            if (cityList) {
                return response.success(res, constant.SUCCESS, cityList);
            } else {
                return response.error(res, constant.NO_RECORD);
            }
        } catch (error) {
            return response.error(res, error.message);
        }
    };
    /**get all coins list  */
    const getCoinsList = async (req, res) => {
        try {
            const coinsList = await Coin.findAll();
            if (!coinsList) {
                return response.recordNotFound(res, req);
            }
            return response.success(res, constant.SUCCESS, coinsList);
        } catch (error) {
            console.log("Error::",error);
            return response.error(res,error.message);
        }
    };
    /**get all General Config list  */
    const getGeneralConfig = async (req, res) => {
        try {
            const generalConfigList = await GeneralConfig.findAll({
                limit: 4
            });
            if (!generalConfigList) {
                return response.recordNotFound(res, req);
            }
            return response.success(res, constant.SUCCESS, generalConfigList);
        } catch (error) {
            console.log("Error::",error);
            return response.error(res,error.message);
        }
    };

    /**update user on the basis of userId */
    const updateGeneralConfig = async (req, res) => {
        try {
            const bodyResp = validateCommon.updateGeneralConfigRecord(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }
            // console.log('TESTEASAA::',req.params.id);
            /**Find User Detail */
            let userupdate = await GeneralConfig.update({configValue: req.body.configValue},{where:{id: req.params.id}});
            console.log('UPDATE:::',userupdate);
            if(!userupdate){
                return response.error(res,constant.SERVER_ERROR);
            }
        return response.successMsg(res, constant.UPDATE_VALUE);
        } catch (error) {
            console.log('error::', error);
            return response.error(res, error.msg);
        }
    };

    /**get ITC Coin  */
    const getCoin = async (req, res) => {
        try {
            let coin = await Coin.findOne({
                where: {symbol: 'ITC'},
            });
            if (!coin) {
                return response.recordNotFound(res, req);
            }
            coin = {
                coinId: coin.coinId,
                rewardCnvrsnPrcnt: parseInt(coin.rewardCnvrsnPrcnt),
                krwToCryptoFeePrcnt: parseInt(coin.krwToCryptoFeePrcnt),
                minRewardConvert: parseFloat(coin.minRewardConvert).toFixed(2),
                minKrwToConvert: parseFloat(coin.minKrwToConvert).toFixed(2)
            }
            return response.success(res, constant.SUCCESS, coin);
        } catch (error) {
            console.log("Error::",error);
            return response.error(res,error.message);
        }
    };

    /**update Coin on the basis of CoinId */
    const updateCoin = async (req, res) => {
        try {
            const bodyResp = validateCommon.updateCoinConfigRecord(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }
            let coinUpdate = await Coin.update({
                rewardCnvrsnPrcnt: req.body.rewardCnvrsnPrcnt, 
                krwToCryptoFeePrcnt: req.body.krwToCryptoFeePrcnt, 
                minRewardConvert: req.body.minRewardConvert, 
                minKrwToConvert: req.body.minKrwToConvert, 
            },{where:{id: req.params.id}});
            console.log('UPDATE:::',coinUpdate);
            if(!coinUpdate){
                return response.error(res,constant.SERVER_ERROR);
            }
        return response.successMsg(res, constant.UPDATE_VALUE);
        } catch (error) {
            console.log('error::', error);
            return response.error(res, error.msg);
        }
    };

    /**it will return the array of sum's like (totalCoupon,totalOutlet,totalcamaign,totaluser,totalcollectedcoupons)
     * on the basis of logged-in merchant's ID
     */
    const allOnDashboard = async (req, res) => {
        try {
            const { user } = req;
            let couponIds = [];
            let couponCount = 0;
            let outletIds = [];
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getOutlets = await Outlet.findAll({ where: { brand_id: brand.id, is_deleted: false } });
            getOutlets.map(Element => {
                outletIds.push(Element.id);
            });
            let getCoupons = await Coupon.findAll({ where: { outlet_id: { [Op.in]: outletIds }, status: 'available', is_deleted: false } });
            let dineInPendingOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds }, status:'PENDING', order_type:'DINE_IN', soft_delete:false }});
            let deliveryPendingOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds }, status:'PENDING', order_type:'DELIVERY', soft_delete:false }});
            let dineInOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds }, soft_delete:false }});
            let deliveryOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds }, soft_delete:false }});
            getCoupons.map(Element => {
                couponIds.push(Element.id);
            });
            let getUser = await User.findAll({ where: { isDeleted: false } });
            const getCollectedCoupons = await CollectedCoupons.findAll({
                attributes: [
                    [Sequelize.fn('COUNT', '*'), 'count'],
                    [Sequelize.col('CouponCode.coupon_id'), 'coupon_id']
                ],
                where: { is_coupon: 'collected', coupon_id: { [Op.in]: couponIds } },
                include: {
                    attributes: [],
                    model: CouponCode,
                    required: true
                },
                group: [Sequelize.col('CouponCode.coupon_id')]
            });
            getCollectedCoupons.map(element => {
                element = element.toJSON();
                couponCount = couponCount + element.count;
            });
            /**
             * making of template response is to make the frontend
             *  cards dynamic including cardStyle and icon.
            */
            template = [
                {
                    "title": "Total Outlets",
                    "value": getOutlets.length,
                    "cardStyle": "border-left-primary",
                    "icon": "fa-store"
                },
                {
                    "title": "Coupons & Colleted",
                    "value": getCoupons.length +' & '+ couponCount,
                    "cardStyle": "border-left-secondary",
                    "icon": "fa-ticket-alt"
                },
                {
                    "title": "Total Dine-in",
                    "value": dineInOrders.length,
                    "cardStyle": "border-left-success",
                    "icon": "fa-utensils"
                },
                {
                    "title": "Pending Dine-in",
                    "value": dineInPendingOrders.length,
                    "cardStyle": "border-left-warning",
                    "icon": "fa-utensils"
                },
                {
                    "title": "Total Delivery",
                    "value": deliveryOrders.length,
                    "cardStyle": "border-left-danger",
                    "icon": "fa-truck"
                },
                {
                    "title": "Pending Delivery",
                    "value": deliveryPendingOrders.length,
                    "cardStyle": "border-left-primary",
                    "icon": "fa-truck"
                }
            ];
            return response.success(res, constant.SUCCESS, template);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**get collected coupons country names and their total sum   */
    const collectedCouponsCountry = async (req, res) => {
        try {
            const { user } = req;
            couponIds = [];
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id } });

            /** Pushing coupons ids in a single array
             * to execute the collected coupon aggregate query in single time.
              */
            getCoupons.map(Element => {
                couponIds.push(Element.id);
            });

            let getCollectedCoupons = await collectedCountries();
            getCollectedCoupons = getCollectedCoupons.map(data => {
                data = data.toJSON();
                return {
                    country: data.CountryList.sort_name,
                    collected: data.count
                };
            });
            return response.success(res, constant.SUCCESS, getCollectedCoupons)
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**get  */
    const countryStateCities = async (req, res) => {
        try {
            let foundCountryList = await CountryList.findAll({ attributes: ['id', ['country_name', 'name'], ['sort_name', 'sortName']] });
            return response.success(res, constant.SUCCESS, foundCountryList);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**get brand list by merchant's id */
    const getMyBrand = async (req, res) => {
        try {
            const { user } = req;
            let brand = await Brand.findOne({
                where: { user_id: user.data.user_id },
                attributes: ['id', ['brand_name', 'name'], 'image', 'category_id', 'country_id', 'postal_code', ['phone_number', 'phoneNumber']]
            });
            return response.success(res, constant.SUCCESS, brand);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**get all  categories  */
    const getCategories = async (req, res) => {
        try {
            let Categories = await Category.findAll({
                attributes: ['id', 'title', 'image'],
                where: {
                    parent_id: null

                }
            });
            return response.success(res, constant.SUCCESS, Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all sub categories  */
    const getsubCategories = async (req, res) => {
        try {
            let Categories = await Category.findAll({
                attributes: ['id', 'title', 'image'],
                where: {
                    parent_id: {
                        [Op.not]: null
                    }
                }
            });
            return response.success(res, constant.SUCCESS, Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all sub categories  Brand for product creation*/
    const getsubCategoriesProduct = async (req, res) => {
        try {
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({
                attributes: ['category_id'],
                where: { id: req.params.brandId }
            });
            let Categories = await Category.findAll({
                attributes: ['id', 'title', 'image'],
                where: {
                    parent_id: brand.dataValues.category_id,
                    // parent_id: {
                    //     [Op.not]: null
                    // }
                }
            });

            /**final response */
            Categories = Categories.map(data => {
                // data = data.toJSON();
                return {
                    id: data.id,
                    title: data.title.toUpperCase(),
                    image: data.image
                };
            });
            return response.success(res, "Product Categories", Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all currencies list */
    const getCurrencies = async (req, res) => {
        try {
            let Currencies = await Currency.findAll({
                attributes: ['id', 'symbol', 'name']
            });
            return response.success(res, constant.SUCCESS, Currencies)
        } catch (error) {
            console.log("Error:::", error)
            return response.error(res, error.message)
        }
    };
    /**get all registered outlets of specific brand(merchant's id)  */
    const getOutlets = async (req, res) => {
        try {
            const { user } = req;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            if (!brand) {
                return response.error(res, constant.SERVER_ERROR);
            }
            let outlets = await Outlet.findAll({
                where: { brand_id: brand.id, is_deleted: false },
                attributes: ['id','address', ['outlet_name', 'name']]
            });
            if (!outlets) {
                return response.recordNotFound(res);
            }
            return response.success(res, constant.SUCCESS, outlets);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get all registered outlets of specific brand(merchant's id)  */
    const allOutletList = async (req, res) => {
        try {
           
            let outlets = await Outlet.findAll({
                where: { is_deleted: false },
                attributes: ['id','address', ['outlet_name', 'name']]
            });
            if (!outlets) {
                return response.recordNotFound(res);
            }
            return response.success(res, constant.SUCCESS, outlets);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get all registered outlets of specific brand(merchant's id)  */
    const getBrands = async (req, res) => {
        try {
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findAll({where:{user_id:{[Op.not]:null}} , attributes:['id',['brand_name','name']]});
            return response.success(res, constant.SUCCESS, brand);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get locations of visitor group by country
     * On the basis of merchant's id.
     */
    const visitorsCountryMap = async (req, res) => {
        try {
            const { user } = req;
            couponIds = [];
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id } });

            /**pushing coupons ids in a single array
             * to execute the collected coupon aggregate query in single time.
              */
            getCoupons.map(Element => {
                couponIds.push(Element.id);
            });
            let getCollectedCoupons = await collectedCountries();
            getCollectedCoupons = getCollectedCoupons.map(data => {
                data = data.toJSON();
                return {
                    title: data.CountryList.country_name,
                    latitude: parseFloat(data.CountryList.latitude),
                    longitude: parseFloat(data.CountryList.longitude)
                };
            });
            return response.success(res, constant.SUCCESS, getCollectedCoupons);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get coupons Status sum's like(available,pending,expired) for pieChart.
     * sum's of all three type of status on the basis of merchant.
     */
    const pieChartCouponStatus = async (req, res) => {
        try {
            const { user } = req;
            let pending = 0;
            let available = 0;
            let expired = 0;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });

            let coupons = await Coupon.findAll({
                where: { brand_id: brand.id }
            });
            /**Taking manual sum of available, pending and expired by simple assignment operator.  */
            coupons.forEach(element => {
                switch (element.status) {
                    case 'available':
                        available = available + 1;
                        break;
                    case 'pending':
                        pending = pending + 1;
                        break;
                    case 'expired':
                        expired = expired + 1;
                        break;
                    default:
                        break;
                }
            });
            /**final Response */
            data = [
                {
                    status: "PENDING",
                    value: pending
                },
                {
                    status: "AVAILABLE",
                    value: available
                },
                {
                    status: "EXPIRED",
                    value: expired
                }
            ];
            return response.success(res, constant.SUCCESS, data);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**get coupon categories having in merchant's system(Account) */
    const pieChartCouponCategory = async (req, res) => {
        try {
            const { user } = req;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });

            /**Agregate query on coupons table */
            let coupons = await Coupon.findAll({
                attributes: [
                    [Sequelize.fn('COUNT', '*'), 'count'],
                    [Sequelize.col('Category.id'), 'category_id']
                ],
                where: { brand_id: brand.id },
                include: { model: Category },
                group: [Sequelize.col('Category.id')]
            });
            coupons = coupons.map(data => {
                data = data.toJSON();
                if(data.Category){
                    return {
                        category: data.Category.title.toUpperCase(),
                        value: data.count
                    };
                }
                
            });
            return response.success(res, constant.SUCCESS, coupons);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    /**all categories list that a brand(merchant) have in their system(Account) */
    const categoriesByBrand = async (req, res) => {
        try {
            const { user } = req;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({
                attributes: ['category_id'],
                where: { user_id: user.data.user_id }
            });

            let Categories = await Category.findAll({
                attributes: ['id', 'title', 'image'],
                where: {
                    parent_id: brand.category_id,
                }
            });

            /**final response */
            Categories = Categories.map(data => {
                // data = data.toJSON();
                return {
                    id: data.id,
                    title: data.title.toUpperCase(),
                    image: data.image
                };
            });
            return response.success(res, "Brand subcategories for Product Category selection", Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**all categories list that a brand(merchant) have in their system(Account) */
    const categoriesByBrandIdUsertest = async (req, res) => {
        try {
            const { user } = req;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            /**sequelize query on coupon to get the categories */




            let Categories = await Category.findAll({
                attributes: ['id', 'title', 'image'],
                where: {
                    parent_id: brand.category_id,
                    // parent_id: {
                    //     [Op.not]: null
                    // }
                }
            });

            /**final response */
            Categories = Categories.map(data => {
                // data = data.toJSON();
                return {
                    id: data.id,
                    title: data.title.toUpperCase(),
                    image: data.image
                };
            });
            return response.success(res, constant.SUCCESS, Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**all categories list that a brand(merchant) have in their system(Account) */
    const categoriesByBrandIdUser = async (req, res) => {
        try {

            console.log(req.body)
            // const { user } = req;
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: req.body.merchant_id, id: req.body.brand_id } });
            /**sequelize query on coupon to get the categories */
            let Categories = await Products.findAll({
                attributes: [
                    [Sequelize.col('category_id'), 'category_id']
                ],
                where: { brand_id: brand.id, id: req.body.outlet_id, user_id: req.body.merchant_id },
                include: { model: Category },
                group: [Sequelize.col('Category.id')]
            });

            console.log(Categories)
            /**final response */
            Categories = Categories.map(data => {
                data = data.toJSON();
                return {
                    id: data.Category.id,
                    title: data.Category.title.toUpperCase(),
                    image: data.Category.image
                };
            });
            return response.success(res, constant.SUCCESS, Categories);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**Sum of all three types collected,redeemed and expired
     * that sum will be on the basis of merchant's id(Account)
      */
    const accountsDetail = async (req, res) => {
        try {
            const { user } = req;
            couponIds = [];
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id } });

            getCoupons.map(Element => {
                couponIds.push(Element.id);
            });
            const getCollectedCoupons = await CollectedCoupons.findAll({
                where: { coupon_id: { [Op.in]: couponIds } }
            });
            let collected = 0;
            let redeemed = 0;
            let expired = 0;
            /**Taking manual sum of redeemed, collected and expired by simple assignment operator.  */
            getCollectedCoupons.forEach(element => {
                switch (element.is_coupon) {
                    case 'redeemed':
                        redeemed = redeemed + 1;
                        break;
                    case 'collected':
                        collected = collected + 1;
                        break;
                    case 'expired':
                        expired = expired + 1;
                        break;
                    default:
                        break;
                }
            });
            data = [
                {
                    status: "COLLECTED",
                    value: collected,
                    icon: 'fa-box-open'
                },
                {
                    status: "REDEEMED",
                    value: redeemed,
                    icon: 'fa-box'
                },
                {
                    status: "EXPIRED",
                    value: expired,
                    icon: 'fa-hourglass-end'
                }
            ];
            return response.success(res, constant.SUCCESS, data);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    };
    /**dashboard summary for Super-Admin(admin) */
    const adminDashboardSummary = async (req, res) => {
        try {
            const { user } = req;
            let outletIds = [];
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findAll({ where: { user_id: {[Op.not]:null} } });
            let getOutlets = await Outlet.findAll({ where: { is_deleted: false } });
            getOutlets.map(Element => {
                outletIds.push(Element.id);
            });
            let dineInOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds },order_type:'DINE_IN', soft_delete:false }});
            let deliveryOrders = await Order.findAll({where:{ outlet_id:{ [Op.in]: outletIds },order_type:'DELIVERY', soft_delete:false }});
            let getUser = await User.findAll({ where: { isDeleted: false } });
            /**
             * making of template response is to make the frontend
             *  cards dynamic including cardStyle and icon.
            */
           template = [
               {
                   "title": "Total Users",
                   "value": getUser.length,
                   "cardStyle": "border-left-secondary",
                   "icon": "fa-users"
               },
               {
                   "title": "Total Brands",
                   "value": brand.length,
                   "cardStyle": "border-left-warning",
                   "icon": "fa-building"
               },
                {
                    "title": "Total Outlets",
                    "value": getOutlets.length,
                    "cardStyle": "border-left-primary",
                    "icon": "fa-store"
                },
                {
                    "title": "Total Dine-in",
                    "value": dineInOrders.length,
                    "cardStyle": "border-left-success",
                    "icon": "fa-utensils"
                },
                {
                    "title": "Total Delivery",
                    "value": deliveryOrders.length,
                    "cardStyle": "border-left-danger",
                    "icon": "fa-truck"
                }
            ];
            return response.success(res, constant.SUCCESS, template);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    };
    /**Redeemed coupons detail for merchant's portal */
    const redeemedCouponDetail = async (req, res) => {
        try {
            const { user } = req;
            let couponIds = [];
            const bodyResposnse = validateCoupon.redeemedCoupons(req.body);
            if (bodyResposnse.status === false) {
                return response.error(res, bodyResposnse.msg);
            }
            /**get brand id on the basis of user_id(merchant id) */
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id } });
            getCoupons.forEach(Element => {
                couponIds.push(Element.id);
            });
            /**sequekize join query on collected Coupons table with pagination */
            let redeemedCoupons = await CollectedCoupons.findAll({
                where: { coupon_id: { [Op.in]: couponIds }, is_coupon: 'redeemed' },
                attributes: ['id', 'updatedAt'],
                include: [{ model: Coupon, attributes: ['id', 'coupon_name', 'coupon_image', 'percent_off', 'amount'] }, {
                    model: User,
                    attributes: ['id', 'full_name']
                }, {
                    model: MpCouponOutlet,
                    attributes: ['outlet_id'],
                    include: {
                        model: Outlet,
                        attributes: ['id', 'outlet_name']
                    }
                }],
                order: [['createdAt', 'desc']],
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1)),
                limit: parseInt(req.body.limit),
            });

            let responseArray = [];

            /**pagination variables */
            let recordsTotal = redeemedCoupons.length;
            let recordsFiltered = redeemedCoupons.length;
            /**end */
            /**setting up final response */
            redeemedCoupons.forEach(element => {
                responseArray.push({
                    id: element.id,
                    name: element.Coupon.coupon_name,
                    image: element.Coupon.coupon_image,
                    offAmount: element.Coupon.amount - ((element.Coupon.percent_off / 100) * element.Coupon.amount),
                    updatedAt: element.updatedAt,
                    user: {
                        name: element.User.full_name
                    },
                    outlet: {
                        name: element.MpCouponOutlet.Outlet.outlet_name
                    }
                })
            })
            return response.successDT(res, constant.SUCCESS, responseArray, recordsTotal, recordsFiltered);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    };
   /**get Five Recent Collected or Hunted Coupons  */
   const recentCollectedCoupons = async (req, res) => {
    try {
        const { user } = req;

        let couponIds = [];
        let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
        let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id, status: 'available', is_deleted: false } });
        getCoupons.map(Element => {
            couponIds.push(Element.id);
        });
        let recordsTotal = 0;
        let recordsFiltered = 0;
        
        let recentResp = await CollectedCoupons.findAll({
                            where: { is_coupon:'collected', coupon_id: { [Op.in]: couponIds }, user_id: { [Op.not]: null } },
                            attributes: ['id'],
                            include:[ 
                                {   model:Coupon, attributes:['coupon_name','percent_off'], include:{ model: Outlet , include: { model:Brand } } },
                                {   model: User, attributes:['full_name'] } ],
                            order: [['createdAt','desc']],
                            offset: 0,
                            limit: 5
                        });
        recentResp = recentResp.map(data=>{
            return {
                userName: data.User.full_name,
                couponName: data.Coupon.coupon_name,
                brand: data.Coupon.Outlet.Brand.brand_name,
                outlet: data.Coupon.Outlet.outlet_name,
                discount: data.Coupon.percent_off,
            }
        });
        recordsTotal = recentResp.length;
        recordsFiltered = recentResp.length;

        return response.successDT(res, constant.SUCCESS, recentResp, recordsTotal, recordsFiltered);
    } catch (error) {
        console.log('Error is::', error);
        return response.error(res, error.message);
    }
    };
     /**get Top Five Coupon Hunters  */
   const topFiveCouponHunters = async (req, res) => {
    try {
        const { user } = req;
        let couponIds = [];
        let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
        if(!brand){
            return response.successDT(res, constant.SUCCESS, [], 0, 0);
        }
        let getCoupons = await Coupon.findAll({ where: { brand_id: brand.id, status: 'available', is_deleted: false } });
        getCoupons.map(Element => {
            couponIds.push(Element.id);
        });
        let recordsTotal = 5;
        let recordsFiltered = 5;
        
        let collectedCoupons = await CollectedCoupons.findAll({
            attributes: [
              [Sequelize.fn("COUNT", "*"), "count"],
              [Sequelize.col("is_coupon"), "isCoupon"],
            ],
            where: { is_coupon: "collected", user_id:{ [Op.not]: null }, coupon_id: { [Op.in]: couponIds } },
            include: {
              model: User,
              include:{ model:UserDetail, include: { model: CountryList } },
              required: true
            },
            group: [
              [Sequelize.col("User.id")],
              [Sequelize.col("is_coupon")]
            ],
          });
          
        collectedCoupons = collectedCoupons.map(data=>{
            let jsonData = data.toJSON();
            return {
                count: jsonData.count,
                userName: jsonData.User.full_name,
                email: jsonData.User.email,
                country: jsonData.User.UserDetails[0].CountryList? jsonData.User.UserDetails[0].CountryList.country_name:''
            }
        });
          collectedCoupons.sort(function(a, b) {
            return parseFloat(b.count) - parseFloat(a.count);
        });
        let finalResp = [];
        for(let i = 0; i < 5; i++){
            console.log('TEST:::', collectedCoupons[i]);
            finalResp.push(collectedCoupons[i]);
        }

        return response.successDT(res, constant.SUCCESS, finalResp, recordsTotal, recordsFiltered);
    } catch (error) {
        console.log('Error is::', error);
        return response.error(res, error.message);
    }
    };
    /**Get Five REcent Delivery Orders  */
    const recentDeliveryOrders = async (req, res) => {
        try {
            const { user } = req;
            var  outletIds = [];
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getOutlets = await Outlet.findAll({ where: { brand_id: brand.id, is_deleted: false } });
            getOutlets.map(Element => {
                outletIds.push(Element.id);
            });
            var OrderData = await Order.findAll({
                where: { outlet_id: { [Op.in]:outletIds }, order_type: 'DELIVERY', soft_delete: false },
                include: [{
                    model: Outlet,
                    include:{model:Brand}
                }, {
                    model: User
                }],
                order:[['createdAt','desc']],
                limit: 5,
                offset: 0
            });
           OrderData= OrderData.map(element=>{
                return{
                    brand: element.Outlet.Brand.brand_name,
                    outlet: element.Outlet.outlet_name,
                    orderBy: element.User.full_name,
                    status: element.status,
                    price: element.total 

                }
            });
            return response.successDT(res, constant.SUCCESS, OrderData, OrderData.length, OrderData.length);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**Get Five REcent Dine-in Orders  */
    const recentDineInOrders = async (req, res) => {
        try {
            const { user } = req;
            var  outletIds = [];
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            let getOutlets = await Outlet.findAll({ where: { brand_id: brand.id, is_deleted: false } });
            getOutlets.map(Element => {
                outletIds.push(Element.id);
            });
            var OrderData = await Order.findAll({
                where: { outlet_id: { [Op.in]: outletIds }, order_type: 'DINE_IN', soft_delete: false },
                include: [{
                    model: Outlet,
                    include: { model: Brand }
                }, {
                    model: User
                }],
                order:[['createdAt','desc']],
                limit: 5,
                offset: 0
            });
            OrderData= OrderData.map(element=>{
                return{
                    brand: element.Outlet.Brand.brand_name,
                    outlet: element.Outlet.outlet_name,
                    orderBy: element.User.full_name,
                    status: element.status,
                    price: element.total 

                }
            });
            return response.successDT(res, constant.SUCCESS, OrderData, OrderData.length, OrderData.length);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**All Brands with Their outlets counpon detail */
    const allBrandsOnDashboard = async (req, res) => {
        try {
            // const { user } = req;
            var finalArray = [];
            /**get brand id on the basis of user_id(merchant id) */
            let AllBrands = await 
            Brand.findAll({ 
                where: {id: req.params.brandId, user_id: {[Op.not]:null} },
                attributes:['id', 'brand_name','image'],
                include:{
                    model: Outlet,
                    attributes:['id','outlet_name'],
                     where: { is_deleted: false },
                    include: { 
                                 model: Coupon,
                                        include: { model: CollectedCoupons } 
                                    }
                }                              
            });
          
            AllBrands.map(data=>{
              if(data.Outlets){
                  let outlets = data.Outlets;
                  outlets.map(ele=>{
                    let coupons = 0;  let totalCouponsQty = 0; let remainingCouponsQty = 0; let collected = 0;
                    let redeemed = 0; let expired = 0;
                    if(ele.Coupons){
                        let couponsArray = ele.Coupons;
                        couponsArray.map(Element=>{
                            if(Element.status=='available'){
                                coupons = coupons + 1;
                                totalCouponsQty = totalCouponsQty + Element.total_coupons;
                                remainingCouponsQty = remainingCouponsQty + Element.remaining_coupons;
                            if(Element.CollectedCoupons){
                                let collectedCoupon = Element.CollectedCoupons;
                                collectedCoupon.forEach(element => {
                                    switch (element.is_coupon) {
                                        case 'COLLECTED':
                                            collected = collected + 1;
                                            break;
                                        case 'REDEEMED':
                                            redeemed = redeemed + 1;
                                            break;
                                        default:
                                            break;
                                        }
                                    });
                                }
                            }else if(Element.status=='expired'){
                                expired = expired + 1;
                            }
                        });
                        finalArray.push({
                            brandName: data.brand_name,
                            brandImage: data.image,
                            outlet: ele.outlet_name,
                            totalCoupons: coupons,
                            couponsQuantity: totalCouponsQty,
                            remaining:  remainingCouponsQty,
                            redeemed: redeemed,
                            expired: expired,
                            collected:collected
        
                        })
                    }
                  }) 
              }
               
               
            });
            return response.success(res, constant.SUCCESS, finalArray);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**For Admin Dashboard get Five Recent Collected or Hunted Coupons  */
   const recentHuntedCoupons = async (req, res) => {
    try {              
        let recentResp = await CollectedCoupons.findAll({
                            where: { is_coupon:'COLLECTED', user_id: { [Op.not]: null } },
                            attributes: ['id'],
                            include:[ 
                                {   model:Coupon, attributes:['coupon_name','percent_off'], include:{ model:Outlet , include: { model:Brand } } },
                                {   model:User, attributes:['full_name'] } ],
                            order: [['createdAt','desc']],
                            offset: 0,
                            limit: 5
                        });
        recentResp = recentResp.map(data=>{
            return {
                userName: data.User.full_name,
                couponName: data.Coupon.coupon_name,
                brand: data.Coupon.Outlet.Brand.brand_name,
                outlet: data.Coupon.Outlet.outlet_name,
                discount: data.Coupon.percent_off,
            }
        });

        return response.success(res, constant.SUCCESS, recentResp);
    } catch (error) {
        console.log('Error is::', error);
        return response.error(res, error.message);
    }
    };
     /**get Top Five Hunters for Admin Dashboard  */
   const topFiveHunters = async (req, res) => {
    try {
        
        let collectedCoupons = await CollectedCoupons.findAll({
            attributes: [
              [Sequelize.fn("COUNT", "*"), "count"],
              [Sequelize.col("is_coupon"), "isCoupon"],
            ],
            where: { is_coupon: "COLLECTED", user_id:{ [Op.not]: null } },
            include: {
              model: User,
              where: {isDeleted:false},
              include:{ model: UserDetail, include: { model: CountryList } },
              required: true
            },
            group: [
              [Sequelize.col("User.id")]
            ],
          });
          
        collectedCoupons = collectedCoupons.map(data=>{
            let jsonData = data.toJSON();
            return {
                count: jsonData.count,
                userName: jsonData.User.full_name,
                email: jsonData.User.email,
                country: jsonData.User.UserDetails[0]?jsonData.User.UserDetails[0].CountryList?  jsonData.User.UserDetails[0].CountryList.country_name:'':''
            }
        });
          collectedCoupons.sort(function(a, b) {
            return parseFloat(b.count) - parseFloat(a.count);
        });
        let finalResp = [];
        for(let i = 0; i < 5; i++){
            finalResp.push(collectedCoupons[i]);
        }
        return response.success(res, constant.SUCCESS, finalResp);
    } catch (error) {
        console.log('Error is::', error);
        return response.error(res, error.message);
    }
    };
    /**Get Five Recent Delivery Orders For Admin DAshboard */
    const recentDelivery = async (req, res) => {
        try {

            var OrderData = await Order.findAll({
                where: { order_type: 'DELIVERY', soft_delete: false },
                include: [{
                    model: Outlet,
                    include:{model:Brand}
                }, {
                    model: User
                }],
                order:[['createdAt','desc']],
                limit: 5,
                offset: 0
            });
           OrderData= OrderData.map(element=>{
                return{
                    brand: element.Outlet.Brand.brand_name,
                    outlet: element.Outlet.outlet_name,
                    orderBy: element.User.full_name,
                    status: element.status,
                    price: element.total 

                }
            });
            return response.success(res, constant.SUCCESS, OrderData);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    /**Get Five Recent Dine-in Orders For Admin Dashboard  */
    const recentDineIn = async (req, res) => {
        try {
            var OrderData = await Order.findAll({
                where: {  order_type: 'DINE_IN', soft_delete: false },
                include: [{
                    model: Outlet,
                    include: { model: Brand }
                }, {
                    model: User
                }],
                order:[['createdAt','desc']],
                limit: 5,
                offset: 0
            });
            OrderData= OrderData.map(element=>{
                return{
                    brand: element.Outlet.Brand.brand_name,
                    outlet: element.Outlet.outlet_name,
                    orderBy: element.User.full_name,
                    status: element.status,
                    price: element.total 

                }
            });
            return response.success(res, constant.SUCCESS, OrderData);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Get All Brands list and Also on the basis of category */
    const allBrandList = async (req, res) => {
        try {
            const validationResponse = validateCommon.brandList(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::",req.body);
            let queryClause;
            let brandCount=0;
            switch (req.body.filterType) {
                case 'all':
                        brandCount = await Brand.count({ where: {user_id: { [Op.not]:null }, is_deleted:false }});
                        queryClause = { user_id: { [Op.not]:null },'is_deleted': false };
                    break;
                case 'category':
                    brandCount = await Brand.count({ where: { user_id: { [Op.not]:null },category_id: req.body.categoryId, is_deleted:false }});
                    queryClause = { 'user_id': { [Op.not]: null },'category_id': req.body.categoryId, 'is_deleted': false };
                    break;

                default:
                    break;
            }
            var brandData = await Brand.findAll({
                where: queryClause,
                include: [{ model: Category }, { model: User }],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (brandData.length != 0) {
                brandData = brandData.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.brand_name,
                        image: Element.image,
                        address: Element.address,
                        phoneNumber: Element.phone_number,
                        category: Element.Category.title,
                        owner: Element.User?Element.User.full_name:'N/A'
                    };
                });
            } else {
                return response.successDT(res, constant.BRAND_NOTFOUND, [], 0, 0);
            }
            return response.successDT(res, constant.SUCCESS, brandData, brandCount, brandCount);
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**search All Brands list and Also on the basis of category */
    const searchBrands = async (req, res) => {
        try {
            const validationResponse = validateCommon.searchBrand(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::",req.body);
            let brandCount=0;
            brandCount = await Brand.count({ where: { brand_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, user_id: { [Op.not]:null }, is_deleted:false }});
            var brandData = await Brand.findAll({
                where: { user_id: { [Op.not]:null }, brand_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'is_deleted': false },
                include: [{ model: Category }, { model: User }],
                order: [['createdAt', 'desc']]
            });
            if (brandData.length != 0) {
                brandData = brandData.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.brand_name,
                        image: Element.image,
                        address: Element.address,
                        phoneNumber: Element.phone_number,
                        category: Element.Category.title,
                        owner: Element.User?Element.User.full_name:'N/A'
                    };
                });
            } else {
                return response.successDT(res, constant.BRAND_NOTFOUND, [], 0, 0);
            }
            return response.successDT(res, constant.SUCCESS, brandData, brandCount, brandCount);
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /** Get Sums and Total of Brands their outlets, coupons,products etc */
    const brandsAccordionData = async (req, res)=>{
        try {

            let brandCount = await Brand.count({ where: { user_id: { [Op.not]:null } } });
            let outletCount = await Outlet.count({ where: { is_deleted: false } });
            let ordersCount = await Order.count({where:{ soft_delete:false }}); 
            let dineInOrdersCount = await Order.count({where:{ order_type: 'DINE_IN', soft_delete:false }});
            let deliveryOrdersCount = await Order.count({where:{ order_type:'DELIVERY', soft_delete:false }});
            let orderPaidAmount = await Order.findAll({
                attributes:[[sequelize.fn('sum', sequelize.col('total')), 'paidTotal']],
                raw:true
            });
            
            let coupon = await Coupon.findAll({
                where: { status:'available', is_deleted:false },
                include: { model: CollectedCoupons }
            });
            let totalCoupons = 0;
            let collected = 0;
            let redeemed = 0;
            let expired = 0;
            let collectedCoupon;
            let totalPaidCoupons = 0;
            /**getting sum of collected, redeemed and expired coupon quantity Manualy*/
            coupon.map(ele=>{
                collectedCoupon = ele.CollectedCoupons;
                totalCoupons = totalCoupons + ele.total_coupons;
                collectedCoupon.forEach(element => {
                    switch (element.is_coupon) {
                        case 'COLLECTED':
                            collected = collected + 1;
                            break;
                        case 'REDEEMED':
                            totalPaidCoupons = totalPaidCoupons + ele.amount;
                            redeemed = redeemed + 1;
                            break;
                        case 'EXPIRED':
                            expired = expired + 1;
                            break;
                        default:
                            break;
                    }
                });
            });
            let deletedCoupon = await Coupon.count({ is_deleted: true });
            /**
             * making of template response is to make the frontend
             *  cards dynamic including cardStyle and icon.
            */
            const template = {
                brandCount,
                outletCount,
                ordersCount,
                dineInOrdersCount,
                deliveryOrdersCount,
                totalPaidOrders: parseInt(orderPaidAmount[0].paidTotal),
                totalCoupons,
                collected,
                redeemed,
                expired,
                deletedCoupon,
                totalPaidCoupons
            }
            return response.success(res, constant.SUCCESS, template);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /**get BrandDetail */
    const brandDetails = async ( req, res )=>{
        try {
            let brands = await Brand.findOne({ 
                where: { id: req.params.brandId },
                include:[
                            { model:Category, attributes:['title'] },
                            { model: CountryList, attributes:['country_name'] },
                            { model: User, attributes:['full_name'] }
                    ]
            });
            if(!brands){
                return response.error(res, constant.BRAND_NOTFOUND);
            }
            let finalArray = [];
            finalArray =  {
                    id: brands.id,
                    name: brands.brand_name,
                    phoneNumber: brands.phone_number,
                    image: brands.image,
                    address: brands.address,
                    postalCode: brands.postal_code,
                    createdAt: brands.createdAt,
                    category: brands.Category.title,
                    country: brands.CountryList? brands.CountryList.country_name:'N/A',
                    merchant: brands.User.full_name
                }

            return response.success(res, constant.SUCCESS, finalArray);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /**Delete ProductTypes by id For Admin Portal  */
    const deleteBrand = async (req, res) => {
        try {
            let deleteRes =  await Brand.update({
                is_deleted: true,
            },{where:{id: req.params.id }});
            console.log("DELETE:::",deleteRes);
            if (!deleteRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res,constant.BRAND_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get Outlets on the basis of brandId with pagination */
    const brandOutlets = async ( req, res )=>{
        try {
            const validationResponse = validateCommon.brandOutlet(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let outletCount = await Outlet.count({ where: { brand_id: req.body.brandId , is_deleted:false } })
            let outlet = await Outlet.findAll({

                    where: { brand_id: req.body.brandId, is_deleted:false },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            if(!outlet){
                return response.successDT(res, constant.OUTLET_NOTFOUND, [], 0, 0);
            }
            outlet = outlet.map(Element => {
                return {
                    id: Element.id,
                    name: Element.outlet_name,
                    address: Element.address,
                    phoneNumber: Element.phone_number,
                    createdAt: Element.createdAt,
                    status: Element.status ? 'Active' : 'Blocked',  
                };
            });
            return response.successDT(res, constant.SUCCESS, outlet, outletCount, outletCount);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /** Get Sums and Totals of Order, dine-in, delivery coupons etc */
    const outletsAccordionData = async (req, res)=>{
        try {

            let ordersCount = await Order.count({where:{ soft_delete:false }}); 
            let dineInOrdersCount = await Order.count({where:{ order_type: 'DINE_IN', soft_delete:false }});
            let deliveryOrdersCount = await Order.count({where:{ order_type:'DELIVERY', soft_delete:false }});
            let orderPaidAmount = await Order.findAll({
                attributes:[[sequelize.fn('sum', sequelize.col('total')), 'paidTotal']],
                raw:true
            });
            
            let coupon = await Coupon.findAll({
                where: { status:'available', is_deleted:false },
                include: { model: CollectedCoupons }
            });
            let totalCoupons = 0;
            let collected = 0;
            let redeemed = 0;
            let expired = 0;
            let collectedCoupon;
            let totalPaidCoupons = 0;
            /**getting sum of collected, redeemed and expired coupon quantity Manualy*/
            coupon.map(ele=>{
                collectedCoupon = ele.CollectedCoupons;
                totalCoupons = totalCoupons + ele.total_coupons;
                collectedCoupon.forEach(element => {
                    switch (element.is_coupon) {
                        case 'COLLECTED':
                            collected = collected + 1;
                            break;
                        case 'REDEEMED':
                            totalPaidCoupons = totalPaidCoupons + ele.amount;
                            redeemed = redeemed + 1;
                            break;
                        case 'EXPIRED':
                            expired = expired + 1;
                            break;
                        default:
                            break;
                    }
                });
            });
            let deletedCoupon = await Coupon.count({ is_deleted: true });
            /**
             * making of template response is to make the frontend
             *  cards dynamic including cardStyle and icon.
            */
            const template = {
                ordersCount,
                dineInOrdersCount,
                deliveryOrdersCount,
                totalPaidOrders: parseInt(orderPaidAmount[0].paidTotal),
                totalCoupons,
                collected,
                redeemed,
                expired,
                deletedCoupon,
                totalPaidCoupons
            }
            return response.success(res, constant.SUCCESS, template);
        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /**Creating categories by Admin  */
    const createCategory = async(req,res)=>{
        try {
            const validationResponse = validateCommon.categoryBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let parent_id;
            console.log("ParentId:::", req.body.parentId);
            (req.body.parentId)? parent_id = req.body.parentId: parent_id = null;
            console.log("Parent_id:::", parent_id);
            await Category.create({
                title: req.body.title,
                image: await uploadImage.upload(req.body.image, 'categories', req.body.imageName,res),
                parent_id: parent_id
            });
            return response.successMsg(res,constant.CATEGORY_CREATED);

        } catch (error) {
            console.log('Error::: ',error)
            return response.error(res,error.message);
        }
    }

    /**GEt All Categories For Admin Portal */
    const getAllCategory = async (req,res)=>{
        try {
            console.log('Body:::',req.body);
            const validationResponse = validateCommon.paginationBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let categoryCount = 0;
            categoryCount = await Category.count();
            let categories = await Category.findAll({
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if(!categories){
                return response.successDT(res, [],0,0);
            }
            if(!categories){
                return response.successDT(res,constant.NO_RECORD,[],0,0);
            }
            let finalArray = [];
            categories.map(category=>{
                  finalArray.push({
                       id: category.id,
                       title: category.title,
                       image: category.image,
                       createdAt: category.createdAt,
                       parent: category.parent_id
                   })
            });
            // categories.map(category=>{
            //      category = category.toJSON();
            //     let childCategory = category.Children;
            //     if(childCategory.length > 1){
            //          childCategory.map(children=>{
            //             finalArray.push( {
            //                 id: children.id,
            //                 title: children.title,
            //                 image: children.image,
            //                 createdAt: children.createdAt,
            //                 parent: category.title
            //             })
            //         })
            //     }else{
            //        finalArray.push({
            //             id: category.id,
            //             title: category.title,
            //             image: category.image,
            //             createdAt: category.createdAt,
            //             parent: 'N/A'
            //         })
            //     }
            // })


            return response.successDT(res,constant.SUCCESS, finalArray, categoryCount,categoryCount);
        } catch (error) {
            console.log('Error:::',error);
            return response.error(res,error.message);
        }
    }

    /**Get Category Detail For Admin Portal */
    const getCategoryDetail = async (req,res)=>{
        try {
            // console.log("Category ID::",req.params.id)
            let category = await Category.findOne({
                attributes:{ exclude:['parent_id'] }, 
                where:{id:req.params.id}});
            if(!category){
                return response.success(res, constant.NO_RECORD,{});
            }
            let finalArray = {};
            finalArray={
                id: category.id,
                title: category.title,
                image: category.image,
                createdAt: category.createdAt
            };
            return response.success(res, constant.SUCCESS, category);
        } catch (error) {
            console.log('Error:::',error);
            return response.error(res, error.message);
        }
    }

    /**GEt All Categories For Admin Portal */
    const searchCategory = async (req,res)=>{
        try {
            const validationResponse = validateCommon.searchBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let categoryCount = 0;
            categoryCount = await Category.count({
                where: {title: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }}
            });
            let categories = await Category.findAll({
                where: { title: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` } }
            });
            if(!categories){
                return response.successDT(res,[],0,0);
            }
            if(!categories){
                return response.successDT(res,constant.NO_RECORD,[],0,0);
            }
            let finalArray = [];
            categories.map(category=>{
                  finalArray.push({
                       id: category.id,
                       title: category.title,
                       image: category.image,
                       createdAt: category.createdAt,
                       parent: category.parent_id
                   })
            });
            return response.successDT(res,constant.SUCCESS, finalArray, categoryCount, categoryCount);
        } catch (error) {
            console.log('Error:::',error);
            return response.error(res,error.message);
        }
    }

    /**Delete Category by id For Admin Portal  */
    const deleteCategory = async (req, res) => {
        try {
            let deletedRes =  await Category.destroy({where:{id: req.params.id }});
            console.log("DELETE:::",deletedRes);
            if (!deletedRes) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res,constant.CATEGORY_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**getOutlet By Brand Id */
    const getOutletByBrandId = async (req,res)=>{
        try {
            console.log("BRAND ID::",req.params.brandId);
            let outlets = await Outlet.findAll({ where:{ brand_id: req.params.brandId }, attributes:['id', 'address', ['outlet_name','name']]});
            if(!outlets){
                return response.error(res, constant.NO_RECORD);
            }
            return response.success(res, constant.SUCCESS,outlets)
        } catch (error) {
            console.log('Error::',error)
            return response.error(res,error.message)
        }
    }

    /**getOutlets List for Admin Portal */
    const getOutletsList = async (req,res)=>{
        try {
            let outlets = await Outlet.findAll({ where:{is_deleted: false }, attributes:['id','address',['outlet_name','name']]});
            if(!outlets){
                return response.error(res, constant.NO_RECORD);
            }
            return response.success(res, constant.SUCCESS,outlets)
        } catch (error) {
            console.log('Error::',error)
            return response.error(res,error.message)
        }
    }

    /**ProductType List for Admin Portal */
    const productTypeList = async (req,res)=>{
        try {
            let productTypes = await ProductType.findAll({ attributes:['id', ['type_title','title']]});
            if(!productTypes){
                return response.error(res, constant.NO_RECORD);
            }
            return response.success(res, constant.SUCCESS,productTypes)
        } catch (error) {
            console.log('Error::',error)
            return response.error(res,error.message)
        }
    }

    /**Get All ProductTypes with pagination For Admin Portal */
    const getAllProductTypes = async (req,res)=>{
        try {
            console.log('Body:::',req.body);
            const validationResponse = validateCommon.paginationBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let typeProductCount = 0;
            typeProductCount = await ProductType.count({where:{is_deleted:false}});
            let typesProduct = await ProductType.findAll({
                where:{is_deleted:false},
                attributes:['id','image','createdAt', ['type_title','title']],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if(!typesProduct){
                return response.successDT(res, [],0,0);
            }
            if(!typesProduct){
                return response.successDT(res,constant.NO_RECORD,[],0,0);
            }
            return response.successDT(res,constant.SUCCESS, typesProduct, typeProductCount,typeProductCount);
        } catch (error) {
            console.log('Error:::',error);
            return response.error(res,error.message);
        }
    }
    
    /**search ProductTypes For Admin Portal */
    const searchProductTypes = async (req,res)=>{
        try {
            const validationResponse = validateCommon.searchBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let typeProductCount = 0;
            typeProductCount = await ProductType.count({
                where: {type_title: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }}
            });
            let typesProduct = await ProductType.findAll({
                attributes:['id','image','createdAt', ['type_title','title']],
                where: { type_title: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` } }
            });
            if(!typesProduct){
                return response.successDT(res,[],0,0);
            }
            if(!typesProduct){
                return response.successDT(res,constant.NO_RECORD,[],0,0);
            }
            return response.successDT(res,constant.SUCCESS, typesProduct, typeProductCount, typeProductCount);
        } catch (error) {
            console.log('Error:::',error);
            return response.error(res,error.message);
        }
    }

    /**Creating ProductType by Admin  */
    const createProductType = async(req,res)=>{
        try {
            const validationResponse = validateCommon.productTypeBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            await ProductType.create({
                type_title: req.body.title,
                image: await uploadImage.upload(req.body.image, 'product-Types', req.body.imageName,res)
            });
            return response.successMsg(res,constant.PRODUCT_TYPE_CREATED);

        } catch (error) {
            console.log('Error::: ',error)
            return response.error(res,error.message);
        }
    }

    /**Delete ProductTypes by id For Admin Portal  */
    const deleteProductType = async (req, res) => {
        try {
            let updateRes =  await ProductType.update({
                is_deleted: true,
            },{where:{id: req.params.id }});
            console.log("DELETE:::",updateRes);
            if (!updateRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res,constant.PRODUCT_TYPE_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**Update ProductType by Admin  */
    const updateProductType = async(req,res)=>{
        try {
            const validationResponse = validateCommon.productTypeBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            await ProductType.update({
                type_title: req.body.title,
                image: await uploadImage.upload(req.body.image, 'product-Types', req.body.imageName,res)
            },{where:{id: req.params.id }});
            return response.successMsg(res,constant.PRODUCT_TYPE_UPDATED);

        } catch (error) {
            console.log('Error::: ',error)
            return response.error(res,error.message);
        }
    }



    return {
        getCountryList,
        statesList,
        citiesList,
        getCoinsList,
        getGeneralConfig,
        getCoin,
        updateCoin,
        updateGeneralConfig,
        collectedCouponsCountry,
        allOnDashboard,
        countryStateCities,
        getMyBrand,
        getCategories,
        getsubCategories,
        getsubCategoriesProduct,
        getCurrencies,
        getOutlets,
        allOutletList,
        pieChartCouponCategory,
        pieChartCouponStatus,
        visitorsCountryMap,
        categoriesByBrand,
        categoriesByBrandIdUser,
        categoriesByBrandIdUsertest,
        accountsDetail,
        adminDashboardSummary,
        redeemedCouponDetail,
        recentCollectedCoupons,
        topFiveCouponHunters,
        recentDeliveryOrders,
        recentDineInOrders,
        allBrandsOnDashboard,
        recentHuntedCoupons,
        topFiveHunters,
        recentDelivery,
        recentDineIn,
        getBrands,
        allBrandList,
        searchBrands,
        deleteBrand,
        brandsAccordionData,
        brandDetails, 
        brandOutlets,
        outletsAccordionData,
        createCategory,
        getAllCategory,
        deleteCategory,
        getCategoryDetail,
        searchCategory,
        getOutletByBrandId,
        getOutletsList,
        productTypeList,
        getAllProductTypes,
        searchProductTypes,
        createProductType,
        deleteProductType
    };
};

module.exports = CommonController;

async function collectedCountries() {
    return await CollectedCoupons.findAll({
        attributes: [
            [Sequelize.fn('COUNT', '*'), 'count'],
            [Sequelize.col('CountryList.id'), 'country_id']
        ],
        where: { coupon_id: { [Op.in]: couponIds } },
        include: [{
            model: CountryList,
            required: true
        }],
        group: [Sequelize.col('CountryList.id')]
    });
}
