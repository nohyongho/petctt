/** Model */
const User = require('../models/User');
const Brand = require('../models/Brand');
const Outlet = require('../models/Outlet');
const CouponCategory = require('../models/CouponCategory');
const Category = require('../models/Categories');
const Currency = require('../models/Currency');
const TimeTable = require('../models/TimeTable');
const Coupon = require('../models/Coupon');
const MpBrandCategory = require('../models/MpBrandCategory');
const MpCouponOutlet = require('../models/MpCouponOutlet');
const CouponCode = require('../models/CouponCode');
const CollectedCoupon = require('../models/CollectedCoupon');
const Campaign = require('../models/Campaign');
const CountryList = require('../models/CountryList');

/**Services  */
const uploadImage = require('../services/imageUpload.service');

/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/CouponValidator');

/** Database */
const sequelize = require('../config/database');

/** Library */
const randomLocation = require('random-location');
const randomString = require('randomstring');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const path = require('path');
const fs = require('fs')


const CouponController = () => {

    /**get all & available, expired, pending coupon list For admin dashboard with filter and pagination    */
    const getCouponList = async (req, res) => {
        try {

            const bodyResposnse = validate.getCoupons(req.body);
            if (bodyResposnse.status === false) {
                return response.error(res, bodyResposnse.msg);
            }
            let { filterType, status, categoryId, outletId } = req.body;
            let queryClause;
            let couponCount=0;
            switch (filterType) {
                case 'status':
                    if(status=='all'){
                        couponCount = await Coupon.count({where:{is_deleted:false}});
                        queryClause = { 'is_deleted': false };
                    }else{
                        couponCount = await Coupon.count({where:{ status: `${ status }`, is_deleted: false } });
                        queryClause = { 'status': `${ status }`, 'is_deleted': false };
                    }
                    break;

                case 'category':
                    couponCount = await Coupon.count({where:{ category_id: `${ categoryId }`, is_deleted: false}});
                    queryClause = { 'category_id': `${ categoryId }`, 'is_deleted': false };
                    break;

                case 'outlet':
                    couponCount = await Coupon.count({where:{ outlet_id: `${ outletId }`, is_deleted: false}});
                    queryClause = { 'outlet_id': `${ outletId }`, 'is_deleted': false };
                    break;

                default:
                    break;
            }
            if(!queryClause){
                return response.successDT(res, constant.NO_RECORD, [],0,0 );
            }
            coupons = await Coupon.findAll({
                where: queryClause,
                include:[{model:Brand},{model:Outlet},{model:Category}],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if(!coupons){
                return response.successDT(res, constant.NO_RECORD, [],0,0 );
            }
            // console.log('TESTING:::', coupons[0].Category);
            coupons = coupons.map(Element => {
                return {
                    id: Element.id,
                    isCoupon: Element.is_coupon,
                    name: Element.coupon_name,
                    totalCoupons: Element.total_coupons,
                    type: Element.coupon_type,
                    couponImage: Element.coupon_image,
                    percentOff: Element.percent_off,
                    maxDiscount: Element.max_discount,
                    price: Element.amount,
                    perUser: Element.per_user,
                    couponCode: Element.coupon_code,
                    desc: Element.description,
                    createdAt:Element.createdAt,
                    totalCoupons: Element.total_coupons,
                    radius: Element.radius,
                    category: Element.Category?Element.Category.title:'',
                    brandImage: Element.Brand.image,
                    outletName: Element.Outlet.outlet_name,
                    validFrom: Element.valid_from,
                    validTill: Element.valid_till,
                    status: Element.status
                };
            });


            return response.successDT(res, constant.SUCCESS, coupons, couponCount, couponCount);
        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };
    /**Search coupon by name for admin portal  */
    const searchCouponByName = async (req, res) => {
        try {
            const validationResponse = validate.searchCouponByName(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::",req.body);
            let couponCount = 0;
            couponCount = await Coupon.count({ where: { coupon_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted:false}});
            var coupons = await  Coupon.findAll({
                where: { coupon_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` },is_deleted:false },
                include:[{model:Brand},{model:Outlet}],
                order: [['createdAt', 'desc']]
            });
            if (coupons.length < 1) {
                return response.successDT(res, constant.NO_RECORD, [], 0, 0);
            } 
            coupons = coupons.map(Element => {
                return {
                    id: Element.id,
                    isCoupon: Element.is_coupon,
                    name: Element.coupon_name,
                    totalCoupons: Element.total_coupons,
                    type: Element.coupon_type,
                    couponImage: Element.coupon_image,
                    percentOff: Element.percent_off,
                    maxDiscount: Element.max_discount,
                    price: Element.amount,
                    perUser: Element.per_user,
                    couponCode: Element.coupon_code,
                    desc: Element.description,
                    totalCoupons: Element.total_coupons,
                    radius: Element.radius,
                    categoryId: Element.category_id,
                    brandImage: Element.Brand.image,
                    outletName: Element.Outlet.outlet_name,
                    validFrom: Element.valid_from,
                    validTill: Element.valid_till,
                    status: Element.status
                };
            });

            return response.successDT(res, constant.SUCCESS, coupons, couponCount, couponCount);
        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };

    /**coupon Details for admin portal  */
    const couponDetail = async (req, res) => {
        try {
            console.log("Body:::::",req.params.couponId);
            var getCoupon = await  Coupon.findOne({
                where: { id: req.params.couponId, is_deleted: false },
                include:[{ model: Brand },{ model: CollectedCoupon },{ model: Outlet },{ model: Category }],
                order: [['createdAt', 'desc']]
            });
            if (!getCoupon) {
                return response.successMsg(res, constant.COUPON_NOTFOUND);
            } 
            let collected = 0;
            let redeemed = 0;
            let expired = 0;
            /**getting sum of collected, redeemed and expired coupon quantity Manualy*/
            let collectedCoupon = getCoupon.CollectedCoupons;
            collectedCoupon.forEach(element => {
                switch (element.is_coupon) {
                    case 'COLLECTED':
                        collected = collected + 1;
                        break;
                    case 'REDEEMED':
                        redeemed = redeemed + 1;
                        break;
                    case 'EXPIRED':
                        expired = expired + 1;
                        break;
                    default:
                        break;
                }
            });
            let finalResponse = {};
            finalResponse= {
                id: getCoupon.id,
                isCoupon: getCoupon.is_coupon,
                name: getCoupon.coupon_name,
                totalCoupons: getCoupon.total_coupons,
                type: getCoupon.coupon_type,
                couponImage: getCoupon.coupon_image,
                percentOff: getCoupon.percent_off,
                maxDiscount: getCoupon.max_discount,
                price: getCoupon.amount,
                perUser: getCoupon.per_user,
                couponCode: getCoupon.coupon_code,
                desc: getCoupon.description,
                totalCoupons: getCoupon.total_coupons,
                radius: getCoupon.radius,
                createdAt: getCoupon.createdAt,
                category: getCoupon.Category.title,
                brandName: getCoupon.Brand.brand_name,
                validFrom: getCoupon.valid_from,
                validTill: getCoupon.valid_till,
                status: getCoupon.status,
                redeemed: redeemed,
                collected: collected,
                expired: expired,
                outletId: getCoupon.Outlet.id,
                outletName: getCoupon.Outlet.outlet_name,
                outletAddress: getCoupon.Outlet.address,
                outletPhoneNumber: getCoupon.Outlet.phone_number,
                outletStatus: getCoupon.Outlet.status ? 'Active' : 'Blocked',
            };

            return response.success(res, constant.SUCCESS, finalResponse);
        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };

    /**get all & available, expired, pending coupon list    */
    const allCouponList = async (req, res) => {
        try {
            const { user } = req;
            const bodyResposnse = validate.couponsList(req.body);
            if (bodyResposnse.status === false) {
                return response.error(res, bodyResposnse.msg);
            }
            const { type, status, outletId } = req.body;

            let coupons;
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            /**all coupons list */
            if (type === 'all') {
                coupons = await Coupon.findAll({
                    where: { outlet_id: outletId, is_deleted: false },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            }
            /**all available, expired or Pending Coupon list  */
            else if (type === 'other') {
                coupons = await Coupon.findAll({
                    where: { status: status, outlet_id: outletId, is_deleted: false },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            }
            let recordsTotal = 0;
            let recordsFiltered = 0;
            recordsTotal = coupons.length;
            recordsFiltered = coupons.length;
            coupons = coupons.map(Element => {
                return {
                    id: Element.id,
                    name: Element.coupon_name,
                    totalCoupons: Element.total_coupons,
                    type: Element.coupon_type,
                    coupon_image: Element.coupon_image,
                    percent_off: Element.percent_off,

                    price: Element.amount,
                    per_user: Element.per_user,
                    coupon_code: Element.coupon_code,
                    desc: Element.description,
                    total_coupons: Element.total_coupons,
                    radius: Element.radius,
                    category_id: Element.category_id,
                    brand_id: Element.brand_id,
                    outlet_id: Element.outlet_id,
                    validFrom: Element.valid_from,
                    validTill: Element.valid_till,
                    status: Element.status
                };
            });


            return response.successDT(res, constant.SUCCESS, coupons, recordsTotal, recordsFiltered);
        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };

    /**creating coupon and assining to multiple outlets */
    const createCoupon = async (req, res) => {
        try {
            const { user } = req;
            const validationResponse = validate.createCouponBody(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            /**adding new coupon */
            let newCoupon = await Coupon.create({
                coupon_name: req.body.name,
                total_coupons: req.body.quantity,
                remaining_coupons: req.body.quantity,
                percent_off: req.body.percentOff,
                valid_from: req.body.validFrom,
                valid_till: req.body.validTill,
                description: req.body.description,
                coupon_image: await uploadImage.upload(req.body.image, 'coupon-images'),
                per_user: req.body.perUser,
                brand_id: req.body.brandId,
                radius: req.body.radius,
                outlet_id: req.body.outletId,
                max_discount: req.body.maximumDiscount,
                coupon_type: 'common',
                status: 'available',
                currency_id: 4,

            });
            if (!newCoupon) {
                return response.error(res, constant.SERVER_ERROR);
            }
            /**Mapping of outlets and newly created coupon*/
            // req.body.outlet.forEach(async (element) => {
            //     await MpCouponOutlet.create({
            //         coupon_id: newCoupon.id,
            //         outlet_id: element
            //     });
            // });
            /**inserting coupon code with new copoun id */
            await CouponCode.create({
                coupon_code: req.body.code,
                coupon_id: newCoupon.id,
                is_used: false
            });
            return response.successMsg(res, constant.COUPON_CREATED);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Update Coupon record */
    const updateCoupon = async (req, res) => {

        try {

            // const body = req.body;
            const body = JSON.parse(req.body.updateCoupon);
            const { user } = req;
            // const confirmPassword = req.body.confirmPassword
            const validationResponse = validate.updatecouponBody(body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }


            //  let { oldPassword, newPassword } = req.body;

            let getcoupon = await Coupon.findOne({ where: { id: body.coupon_id } });

            if (getcoupon) {


                let updatecoupondata = await Coupon.update({
                    coupon_name: body.coupon_name,

                    total_coupons: body.total_coupons,

                    percent_off: body.percent_off,
                    valid_from: body.valid_from,
                    valid_till: body.valid_till,
                    description: body.description,

                    per_user: body.per_user,

                    radius: body.radius,
                    outlet_id: body.outlet_id,
                    amount: body.amount,
                    category_id: body.category_id,
                    coupon_code: body.coupon_code,
                },

                    {
                        where: { id: body.coupon_id }
                    });

                if (typeof req.file != 'undefined') {




                    const imagename = getcoupon.coupon_image;

                    let imagearr = imagename.split("cImage/");



                    const imagedirpath = path.join(__dirname, '../public/models/images/coupons/') + imagearr[1]

                    console.log(imagedirpath)

                    fs.unlink(imagedirpath, (err) => {
                        if (err) {
                            console.error(err)
                            return
                        }

                        //file removed
                    })




                    await Coupon.update({


                        coupon_image: '/cImage/' + req.file.filename,
                    },

                        {
                            where: { id: body.coupon_id }
                        });

                }



                if (updatecoupondata[0] === 1) {
                    response.successMsg(res, constant.COUPON_UPDATED);
                } else {
                    return response.error(res, "Coupon Not Updated");
                }

            } else {
                return response.error(res, constant.COUPON_NOTFOUND);
            }

        } catch (error) {
            return response.error(res, error.message);
        }
    }

    /**Get All parent Categories */
    const getCategories = async (req, res) => {

        let foundCategories = await Category.findAll({
            attributes: ['id', 'title', 'image', 'description'],
            where: {
                parent_id: null
            }
        });
        if (!foundCategories) {
            return response.recordNotFound(res);
        }

        const data = [];
        for (let category of foundCategories) {
            data.push({
                id: category.id,
                name: category.title,
                description: category.description,
                image: category.image,
            });
        }

        return response.success(res, constant.SUCCESS, data);
    };
    /**getting brands detail on the basis of category */
    const getBrandByCategoryId = async (req, res) => {

        const { categoryId } = req.params;
        if (!categoryId) {
            return response.error(res, constant.SERVER_ERROR);
        }

        const foundData = await MpBrandCategory.findAll({
            where: {
                category_id: categoryId
            },
            include: [
                {
                    model: Brand,
                    include: {
                        model: CountryList
                    }
                },
            ]
        });

        if (!foundData) {
            return response.recordNotFound(res);
        }

        const brands = [];

        for (let ele of foundData) {
            brands.push({
                id: ele.Brand.id,
                brandName: ele.Brand.brand_name,
                email: ele.Brand.email,
                phoneNumber: ele.Brand.phone_number,
                address: ele.Brand.address,
                countryName: ele.Brand.CountryList.country_name,
                logo: ele.Brand.logo,
                description: ele.Brand.description,
                createdAt: ele.Brand.createdAt
            });
        }

        return response.success(res, constant.SUCCESS, brands);

    };
    /**get sigle coupon detail on the basis of coupon ID */
    const getCouponDetail = async (req, res) => {
        try {
            let coupon = await Coupon.findOne({
                where: { id: req.params.id },
                include: [{ model: CollectedCoupon }, { model: Currency, include: CountryList }, {
                    model: MpCouponOutlet,
                    include: { model: Outlet, include: { model: TimeTable } }
                }, { model: Category, attributes: ['title'] }, { model: Brand, attributes: ["brand_name", "image"], include: { model: Category, attributes: ['title'] } }]
            });
            let collected = 0;
            let redeemed = 0;
            let expired = 0;
            /**getting sum of collected, redeemed and expired coupon quantity Manualy*/
            let collectedCoupon = coupon.CollectedCoupons;
            collectedCoupon.forEach(element => {
                switch (element.is_coupon) {
                    case 'collected':
                        collected = collected + 1;
                        break;
                    case 'redeemed':
                        redeemed = redeemed + 1;
                        break;
                    case 'expired':
                        expired = expired + 1;
                        break;
                    default:
                        break;
                }
            });
            /**mapping and prepairing respone of outlet. */
            let outlet = coupon.MpCouponOutlets;
            if (outlet[0] >= 1) {
                outlet = outlet.map(Element => {
                    return {
                        id: Element.Outlet.id,
                        name: Element.Outlet.outlet_name,
                        address: Element.Outlet.address,
                        phoneNumber: Element.Outlet.phone_number,
                        createdAt: Element.Outlet.createdAt,
                        status: Element.Outlet.status ? 'Active' : 'Blocked',
                    };
                });
            }
            /**final Data */
            let data = {
                id: coupon.id,
                name: coupon.coupon_name,
                image: coupon.coupon_image,
                description: coupon.description,
                type: coupon.coupon_type,
                total: coupon.total_coupons,
                remaining: coupon.remaining_coupons,
                fullAmount: coupon.amount,
                percentOff: coupon.percent_off + '%',
                offAmount: coupon.amount - ((coupon.percent_off / 100) * coupon.amount),
                validFrom: coupon.valid_from,
                validTill: coupon.valid_till,
                createdAt: coupon.createdAt,
                status: coupon.status,
                perUser: coupon.per_user,
                category: coupon.Category ? coupon.Category.title : '',
                redeemed: redeemed,
                collected: collected,
                expired: expired,
                country: {
                    name: (coupon.Currency && coupon.Currency.CountryList) ? coupon.Currency.CountryList.country_name : ''
                },
                currency: {
                    id: coupon.Currency ? coupon.Currency.id : '',
                    name: coupon.Currency ? coupon.Currency.name : '',
                    symbol: coupon.Currency ? coupon.Currency.symbol : ''
                },
                brand: {
                    name: coupon.Brand.brand_name,
                    image: coupon.Brand.image,
                    category: coupon.Brand.Category.title
                }, outlet
            };
            return response.success(res, constant.SUCCESS, data);

        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };
    /**Active Coupons or available coupons */
    const activeCouponSummary = async (req, res) => {
        const { user } = req;

        if (!user) {
            return response.unauthorized(res, 'Unauthorized');
        }

        Coupon.findAll({
            where: {
                status: 'available'
            },
            attributes: [
                ['coupon_name', 'couponName'],
                ['total_coupons', 'totalCoupons'],
                ['remaining_coupons', 'remainingCoupons'],
                [sequelize.col('Brand.brand_name'), 'brandName'],
                [sequelize.col('Brand.image'), 'brandImage'],
            ],
            include: [
                {
                    model: Brand,
                    attributes: []
                }
            ]
        }).then(data => {
            if (!data) {
                return response.recordNotFound(res);
            }

            const parsedData = data.map(ele => {
                return ele.toJSON();
            });

            return response.success(res, 'ok', parsedData);
        }).catch(error => {
            return response.error(res, error.message);
        });
    };
    
    /**Get Order list on the basis of selected user id */
    const getCouponListByUser = async (req, res) => {
    try {
        console.log('BODY::::', req.body);
        const validationResponse = validate.couponsListByUser(req.body);
        if (!validationResponse.status) {
            return response.bodyNotFound(res, validationResponse.msg);
        }
        
        let coupons;
        let counponCount = 0;
        counponCount = await CollectedCoupon.count({ where: { user_id: req.body.userId },include:{model: Coupon, where:{is_deleted:false}}});
        coupons = await CollectedCoupon.findAll({
                where: { user_id: req.body.userId },
                include:[{ 
                            model:Coupon, 
                            where: { is_deleted: false },
                            include:[{ model:Outlet },{ model:Brand }]
                        }],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });

            coupons = coupons.map(Element => {
                return {
                    id: Element.Coupon.id,
                    isCoupon: Element.is_coupon,
                    name: Element.Coupon.coupon_name,
                    totalCoupons: Element.Coupon.total_coupons,
                    type: Element.Coupon.coupon_type,
                    couponImage: Element.Coupon.coupon_image,
                    percentOff: Element.Coupon.percent_off,
                    maxDiscount: Element.Coupon.max_discount,
                    price: Element.Coupon.amount,
                    perUser: Element.Coupon.per_user,
                    couponCode: Element.Coupon.coupon_code,
                    desc: Element.Coupon.description,
                    totalCoupons: Element.Coupon.total_coupons,
                    radius: Element.Coupon.radius,
                    categoryId: Element.Coupon.category_id,
                    brandImage: Element.Coupon.Brand.image,
                    outletName: Element.Coupon.Outlet.outlet_name,
                    validFrom: Element.Coupon.valid_from,
                    validTill: Element.Coupon.valid_till,
                    status: Element.Coupon.status
                };
            });

        return response.successDT(res, constant.SUCCESS, coupons, counponCount, counponCount);

    } catch (error) {
        console.log('Error:::', error);
        return response.error(res, error.message);
    }

    };

    const searchCouponsByUser = async (req, res) => {
        try {
            const validationResponse = validate.searchCouponByUser(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::",req.body);
            let counponCount = 0;
            counponCount = await CollectedCoupon.count({ where: { user_id: req.body.userId },include:{model: Coupon, where:{ coupon_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted:false}}});
            var coupons = await  CollectedCoupon.findAll({
                where: { user_id: req.body.userId },
                include:[{ 
                            model: Coupon, 
                            where: { coupon_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted: false },
                            include:[{ model:Outlet },{ model:Brand }]
                        }],
                order: [['createdAt', 'desc']]
            });
            if (coupons.length < 1) {
                return response.successDT(res, constant.NO_RECORD, [], 0, 0);
            } 
            coupons = coupons.map(Element => {
                return {
                    id: Element.Coupon.id,
                    isCoupon: Element.is_coupon,
                    name: Element.Coupon.coupon_name,
                    totalCoupons: Element.Coupon.total_coupons,
                    type: Element.Coupon.coupon_type,
                    couponImage: Element.Coupon.coupon_image,
                    percentOff: Element.Coupon.percent_off,
                    price: Element.Coupon.amount,
                    perUser: Element.Coupon.per_user,
                    couponCode: Element.Coupon.coupon_code,
                    desc: Element.Coupon.description,
                    totalCoupons: Element.Coupon.total_coupons,
                    radius: Element.Coupon.radius,
                    categoryId: Element.Coupon.category_id,
                    brandImage: Element.Coupon.Brand.image,
                    outletName: Element.Coupon.Outlet.outlet_name,
                    validFrom: Element.Coupon.valid_from,
                    validTill: Element.Coupon.valid_till,
                    status: Element.Coupon.status
                };
            });

            return response.successDT(res, constant.SUCCESS, coupons, counponCount, counponCount);


        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Delete Outlet by id For Admin Portal  */
    const deleteCoupon = async (req, res) => {
        try {
            let deleteRes =  await Coupon.update({
                is_deleted: true,
            },{where:{id: req.params.id }});
            console.log("DELETE:::",deleteRes);
            if (!deleteRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res,constant.COUPON_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };


    return {
        allCouponList,
        createCoupon,
        updateCoupon,
        getCategories,
        getBrandByCategoryId,
        getCouponDetail,
        activeCouponSummary,
        getCouponListByUser,
        searchCouponsByUser,
        getCouponList,
        searchCouponByName,
        couponDetail,
        deleteCoupon
    };
};

module.exports = CouponController;