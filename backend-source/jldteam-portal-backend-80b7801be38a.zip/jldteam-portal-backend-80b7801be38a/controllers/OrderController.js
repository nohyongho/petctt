/** Model */
const Order = require('../models/Order');
const User = require('../models/User');
const Outlet = require('../models/Outlet');
const Brand = require('../models/Brand');
/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/OrderValidator');
/** Library */
const Sequelize = require('sequelize');
const Op = Sequelize.Op;


const OrderController = () => {

    /**Get Order list on the basis of selected Outlet id */
    const allOrderList = async (req, res) => {
        try {

            const validationResponse = validate.orderList(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            var OrderData = await Order.findAll({
                where: { outlet_id: req.body.outletId, order_type: req.body.orderType, soft_delete: false },
                include: [{
                    model: Outlet
                }, {
                    model: User
                }],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (OrderData.length != 0) {
                orderList = OrderData.map(Element => {
                    return {
                        id: Element.id,
                        total: Element.total,
                        subTotal: Element.sub_total,
                        vat: Element.vat,
                        couponCode: Element.coupon_code,
                        couponDiscount: Element.coupon_discount,
                        paymentType: Element.payment_type,
                        paymentStatus: Element.payment_status,
                        orderType: Element.order_type,
                        status: Element.status,
                        orderStateTimeChange: Element.order_state_time_change,
                        cancelCharges: Element.cancel_charges,
                        userAddressId: Element.user_address_id,
                        createdAt: Element.createdAt,
                        itemQuantity: Element.item_quantity,
                        instructions: Element.instructions,
                        cancelReason: Element.cancel_reason,
                        waitingTime: Element.waiting_time,
                        softDelete: Element.soft_delete,
                    };
                });
            } else {
                return response.error(res, constant.ORDER_NOTFOUND);
            }
            return response.successDT(res, constant.SUCCESS, orderList, OrderData.length, OrderData.length);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Get Order list on the basis of selected user id */
    const ordersByUser = async (req, res) => {
        try {
            const validationResponse = validate.orderListByUser(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::", req.body);
            let queryClause;
            let orderCount=0;
            switch (req.body.filterType) {
                case 'all':
                        orderCount = await Order.count({ where: {user_id: req.body.userId ,  soft_delete:false }});
                        queryClause = { user_id: `${req.body.userId}`, 'soft_delete': false };
                    break;
                case 'other':
                    orderCount = await Order.count({ where:{ user_id: req.body.userId, order_type: `${ req.body.orderType }`, soft_delete: false }});
                    queryClause = { 'user_id': `${req.body.userId}`, 'order_type': `${req.body.orderType}`, 'soft_delete': false };
                    break;

                default:
                    break;
            }
            var OrderData = await Order.findAll({
                where: queryClause,
                include: [{
                    model: Outlet,
                    include:{ model:Brand }
                }, {
                    model: User
                }],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (OrderData.length != 0) {
                orderList = OrderData.map(Element => {
                    return {
                        id: Element.id,
                        total:parseInt(Element.total),
                        subTotal: Element.sub_total,
                        brandImage: Element.Outlet.Brand.image,
                        vat: Element.vat,
                        couponCode: Element.coupon_code,
                        couponDiscount: Element.coupon_discount,
                        paymentType: Element.payment_type,
                        paymentStatus: Element.payment_status,
                        orderType: Element.order_type,
                        status: Element.status,
                        orderStateTimeChange: Element.order_state_time_change,
                        cancelCharges: Element.cancel_charges,
                        userAddressId: Element.user_address_id,
                        createdAt: Element.createdAt,
                        itemQuantity: Element.item_quantity,
                        instructions: Element.instructions,
                        cancelReason: Element.cancel_reason,
                        waitingTime: Element.waiting_time,
                        softDelete: Element.soft_delete,
                    };
                });
            } else {
                return response.error(res, constant.ORDER_NOTFOUND);
            }
            return response.successDT(res, constant.SUCCESS, orderList, orderCount, orderCount);
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    
    /**Get Order list on the basis of selected user id */
    const searchOrdersByUser = async (req, res) => {
        try {
            const validationResponse = validate.searchOrderByUSer(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let orderCount=0;
            console.log("Body:::::",req.body);
            orderCount = await Order.count({ where: {user_id: req.body.userId ,  payment_status: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete:false }});
             var OrderData = await Order.findAll({
                where: {user_id: `${req.body.userId}`, payment_status: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete: false },
                include: [{
                    model: Outlet,
                    include:{ model:Brand }
                }, {
                    model: User
                }],
                order: [['createdAt', 'desc']]
            });
            if (OrderData.length != 0) {
                
                OrderData = OrderData.map(Element => {
                    return {
                        id: Element.id,
                        total:parseInt(Element.total),
                        subTotal: Element.sub_total,
                        brandImage: Element.Outlet.Brand.image,
                        vat: Element.vat,
                        couponCode: Element.coupon_code,
                        couponDiscount: Element.coupon_discount,
                        paymentType: Element.payment_type,
                        paymentStatus: Element.payment_status,
                        orderType: Element.order_type,
                        status: Element.status,
                        orderStateTimeChange: Element.order_state_time_change,
                        cancelCharges: Element.cancel_charges,
                        userAddressId: Element.user_address_id,
                        createdAt: Element.createdAt,
                        itemQuantity: Element.item_quantity,
                        instructions: Element.instructions,
                        cancelReason: Element.cancel_reason,
                        waitingTime: Element.waiting_time,
                        softDelete: Element.soft_delete,
                    };
                });
                return response.successDT(res, constant.SUCCESS, OrderData, orderCount,orderCount);
            } else {
                return response.successDT(res, constant.NO_RECORD, [], 0, 0);
            }
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Get All Order list For Admin */
    const getAllOrdersList = async (req, res) => {
        try {
            const validationResponse = validate.getAllorders(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            console.log("Body:::::",req.body);
            let queryClause;
            let orderCount=0;
            switch (req.body.filterType) {
                case 'all':
                    orderCount = await Order.count({ where: { soft_delete:false }});
                    queryClause = { 'soft_delete': false };
                    break;
                case 'outlet':
                    if(req.body.orderType){
                        console.log('orderType IFPARTS:::', req.body.orderType);
                        orderCount = await Order.count({ where: { order_type: `${ req.body.orderType }`, outlet_id: `${ parseInt(req.body.outletId) }`, soft_delete: false } });
                        queryClause = { 'order_type': `${req.body.orderType}`, 'outlet_id': `${ parseInt(req.body.outletId) }`, 'soft_delete': false };
                    }else{
                        console.log('orderType:::', req.body.orderType);
                        orderCount = await Order.count({ where: { outlet_id: `${ parseInt(req.body.outletId) }`, soft_delete: false } });
                        queryClause = { 'outlet_id': `${ parseInt(req.body.outletId) }`, 'soft_delete': false };

                    }
                break;
                case 'other':
                    orderCount = await Order.count({ where:{ order_type: `${ req.body.orderType }`, soft_delete: false }});
                    queryClause = { 'order_type': `${req.body.orderType}`, 'soft_delete': false };
                    break;

                default:
                    break;
            }
            var OrderData = await Order.findAll({
                where: queryClause,
                include: [{
                    model: Outlet,
                    include:{ model:Brand }
                }, {
                    model: User
                }],
                order: [['createdAt', 'desc']],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (OrderData.length != 0) {
                orderList = OrderData.map(Element => {
                    return {
                        id: Element.id,
                        total: parseInt(Element.total),
                        subTotal: parseInt(Element.sub_total),
                        brandImage: Element.Outlet.Brand.image,
                        vat: Element.vat,
                        couponCode: Element.coupon_code,
                        couponDiscount: Element.coupon_discount,
                        paymentType: Element.payment_type,
                        paymentStatus: Element.payment_status,
                        orderType: Element.order_type,
                        status: Element.status,
                        orderStateTimeChange: Element.order_state_time_change,
                        cancelCharges: Element.cancel_charges,
                        userAddressId: Element.user_address_id,
                        createdAt: Element.createdAt,
                        itemQuantity: Element.item_quantity,
                        instructions: Element.instructions,
                        cancelReason: Element.cancel_reason,
                        waitingTime: Element.waiting_time,
                        softDelete: Element.soft_delete,
                    };
                });
            } else {
                return response.error(res, constant.ORDERS_NOTFOUND);
            }
            return response.successDT(res, constant.SUCCESS, orderList, orderCount, orderCount);
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };
    
    /**Search Order list For Admin */
    const searchOrders = async (req, res) => {
        try {
            const validationResponse = validate.searchOrders(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let orderCount=0;
            console.log("Body:::::",req.body);
            orderCount = await Order.count({ where: { id: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete:false }});
                var OrderData = await Order.findAll({
                where: { id: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete: false },
                include: [{
                    model: Outlet,
                    include:{ model:Brand }
                }, {
                    model: User
                }],
                order: [['createdAt', 'desc']]
            });
            if (OrderData.length != 0) {
                
                OrderData = OrderData.map(Element => {
                    return {
                        id: Element.id,
                        total:parseInt(Element.total),
                        subTotal: parseInt(Element.sub_total),
                        brandImage: Element.Outlet.Brand.image,
                        vat: Element.vat,
                        couponCode: Element.coupon_code,
                        couponDiscount: Element.coupon_discount,
                        paymentType: Element.payment_type,
                        paymentStatus: Element.payment_status,
                        orderType: Element.order_type,
                        status: Element.status,
                        orderStateTimeChange: Element.order_state_time_change,
                        cancelCharges: Element.cancel_charges,
                        userAddressId: Element.user_address_id,
                        createdAt: Element.createdAt,
                        itemQuantity: Element.item_quantity,
                        instructions: Element.instructions,
                        cancelReason: Element.cancel_reason,
                        waitingTime: Element.waiting_time,
                        softDelete: Element.soft_delete,
                    };
                });
                return response.successDT(res, constant.SUCCESS, OrderData, orderCount,orderCount);
            } else {
                return response.successDT(res, constant.NO_RECORD, [], 0, 0);
            }
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    return {
        allOrderList,
        ordersByUser,
        searchOrdersByUser,
        getAllOrdersList,
        searchOrders
    };
};

module.exports = OrderController;