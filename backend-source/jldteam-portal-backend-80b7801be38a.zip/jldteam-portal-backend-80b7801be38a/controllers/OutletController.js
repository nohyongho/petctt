/** Model */
const Brand = require('../models/Brand');
const Outlet = require('../models/Outlet');
const User = require('../models/User');
const Country = require('../models/CountryList');
const Coupon = require('../models/Coupon');
const City = require('../models/CityList');
const Category = require('../models/Categories');
const Product = require('../models/Products');
/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/OutletValidator');

const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const Op = Sequelize.Op;


const OutletController = () => {

    /**Get outlet list on the basis of logged-in merchant id */
    const allOutletList = async (req, res) => {
        try {


            const { user } = req;
            const validationResponse = validate.outletList(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }

            // console.log("ooooooooooooper")
            //  let brand = await Brand.findAll({ where: { user_id: user.data.user_id } });
            // console.log("neechy")
            // console.log(brand)


            var OutletData = await Outlet.findAll({

                where: { user_id: user.data.user_id, is_deleted: false },
                include: [{
                    model: Brand,
                    required: true,
                    where: {
                        user_id: user.data.user_id
                    },
                    include: {
                        model: Category
                    }
                },
                {

                    model: City,
                    include: {
                        model: Country
                    }
                }
                ],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (OutletData.length != 0) {
                testData = OutletData.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.outlet_name,
                        address: Element.address,
                        postal_code: Element.postal_code,
                        phoneNumber: Element.phone_number,


                        longitude: Element.longitude,
                        latitude: Element.latitude,


                        streetName: Element.street_name,
                        cityName: Element.city_name,


                        stateName: Element.state_name,
                        country_code: Element.country_code,



                        createdAt: Element.createdAt,
                        status: Element.status ? 'Active' : 'Blocked',
                        country: {
                            name: Element.CountryList ? Element.CountryList.country_name : '',
                            sortName: Element.CountryList ? Element.CountryList.sort_name : '',
                        },
                        // state: {
                        //     name: Element.StateList ? Element.StateList.state_name : '',
                        // },
                        city: {
                            id: Element.CityList ? Element.CityList.id : '',
                            name: Element.CityList ? Element.CityList.city_name : '',
                        },
                        brand: {
                            id: Element.Brand.id,
                            name: Element.Brand.brand_name,
                            image: Element.Brand.image,
                            brandcategory: Element.Brand.Category.title

                        }
                    };
                });
            } else {
                return response.error(res, constant.OUTLET_NOTFOUND);
            }


            return response.successDT(res, constant.SUCCESS, testData, OutletData.length, OutletData.length);
            // console.log(testData);



        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /** Get All Outlets For Admin Portal */
    const getAllOutlets = async (req,res)=>{
        try {
            const validationResponse = validate.allOutlets(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let queryClause;
            let outletCount=0;
            switch (req.body.filterType) {
                case 'all':
                    outletCount = await Outlet.count({ where: { is_deleted:false } })
                    queryClause = {'is_deleted': false };
                    break;
                case 'brand':
                    outletCount = await Outlet.count({ where: { brand_id: req.body.brandId , is_deleted: false } })
                    queryClause = { 'brand_id': req.body.brandId, 'is_deleted':false };
                    break;

                default:
                    break;
            }
            
            let outlet = await Outlet.findAll({
                    where: queryClause,
                    include:{model:Brand,include:{model:User}},
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            if(!outlet){
                return response.successDT(res, constant.OUTLET_NOTFOUND, [], 0, 0);
            }
            outlet = outlet.map(Element => {
                return {
                    id: Element.id,
                    name: Element.outlet_name,
                    address: Element.address,
                    phoneNumber: Element.phone_number,
                    createdAt: Element.createdAt,
                    status: Element.status ? 'Active' : 'Blocked',
                    merchant: Element.Brand.User?Element.Brand.User.full_name:'N/A',
                    brandName: Element.Brand.brand_name  
                };
            });
            return response.successDT(res, constant.SUCCESS, outlet, outletCount, outletCount);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /** search Outlets For Admin Portal */
    const searchOutlet = async (req,res)=>{
        try {
            const validationResponse = validate.searchOutlet(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let outletCount = 0;
            outletCount = await Outlet.count({ where: { outlet_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted:false } })
            let outlet = await Outlet.findAll({
                    where: { outlet_name: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted:false },
                    include:{model:Brand,include:{model:User}},
                    order: [['createdAt', 'desc']]
                });
            if(!outlet){
                return response.successDT(res, constant.OUTLET_NOTFOUND, [], 0, 0);
            }
            outlet = outlet.map(Element => {
                return {
                    id: Element.id,
                    name: Element.outlet_name,
                    address: Element.address,
                    phoneNumber: Element.phone_number,
                    createdAt: Element.createdAt,
                    status: Element.status ? 'Active' : 'Blocked',
                    merchant: Element.Brand.User?Element.Brand.User.full_name:'N/A',
                    brandName: Element.Brand.brand_name  
                };
            });
            return response.successDT(res, constant.SUCCESS, outlet, outletCount, outletCount);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /** Get Outlet For Admin Portal */
    const outletDetailforAdmin = async (req, res)=>{
    try {
              
        let outlet = await Outlet.findOne({
                where: { id: req.params.outletId, is_deleted: false },
                include:{ model: Brand, include:{ model :User }},
            });
        let finalArray = [];
        finalArray = {
            id: outlet.id,
            name: outlet.outlet_name,
            address: outlet.address,
            longitude: outlet.longitude,
            latitude: outlet.latitude,
            streetName: outlet.street_name,
            cityName: outlet.city_name,
            stateName: outlet.state_name,
            phoneNumber: outlet.phone_number,
            createdAt: outlet.createdAt,
            status: outlet.status ? 'Active' : 'Blocked',
            merchant: outlet.Brand.User? outlet.Brand.User.full_name:'N/A',
            brandName: outlet.Brand.brand_name,
            brandImage: outlet.Brand.image
        }

        return response.success(res, constant.SUCCESS, finalArray);     
    }catch (error) {
        console.log('Error:::', error);
        return response.error(res, error.message);
    }
    }

    /**Get outlet list on the basis of logged-in merchant id */
    const outletDetail = async (req, res) => {
        try {

            const { user } = req;

            let OutletData = await
                Outlet.findOne({
                    where: { id: req.params.id },
                    include: [{
                        model: Brand,
                        include: {
                            model: Category
                        }
                    },
                    {
                        model: City,
                        include: {
                            model: Country
                        }
                    }, {
                        model: Product
                    }
                    ]
                });
            if (!OutletData) {
                return response.error(res, constant.OUTLET_NOTFOUND);
            }
            let product = OutletData.products.map((product) => {
                return {
                    id: product.id,
                    name: product.product_name,
                    productDescription: product.product_desc,
                    productPrice: product.price,
                    productImage: product.image,
                    createdAt: product.createdAt,
                    status: product.status ? 'Active' : 'InActive'
                }
            })

            responseArrray = {
                id: OutletData.id,
                name: OutletData.outlet_name,
                address: OutletData.address,
                postalCode: OutletData.postal_code,
                phoneNumber: OutletData.phone_number,
                longitude: OutletData.longitude,
                latitude: OutletData.latitude,
                streetName: OutletData.street_name,
                cityName: OutletData.city_name,
                stateName: OutletData.state_name,
                createdAt: OutletData.createdAt,
                status: OutletData.status ? 'Active' : 'Blocked',

                country: {
                    id: OutletData.CountryList ? OutletData.CountryList.id : '',
                    name: OutletData.CountryList ? OutletData.CountryList.country_name : '',
                    sortName: OutletData.CountryList ? OutletData.CountryList.sort_name : '',
                },

                brand: {
                    id: OutletData.Brand.id,
                    name: OutletData.Brand.brand_name,
                    image: OutletData.Brand.image,
                    category: OutletData.Brand.Category.title
                },
                product
            }


            return response.success(res, constant.SUCCESS, responseArrray);
            // console.log(testData);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**Update outlet record */
    const updateoutlet = async (req, res) => {
        try {
            const { user } = req;
            // const confirmPassword = req.body.confirmPassword
            const validationResponse = validate.updateoutlet(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }


            //  let { oldPassword, newPassword } = req.body;

            let getOutlet = await Outlet.findOne({ where: { id: req.body.outlet_id, user_id: user.data.user_id } });

            if (getOutlet) {


                let updateOutletdata = await Outlet.update({

                    outlet_name: req.body.outlet_name,
                    postal_code: req.body.postal_code,
                    address: req.body.address,
                    phone_number: req.body.phone_number,
                    brand_id: req.body.brand_id,
                    city_id: req.body.city_id,
                    //  area: req.body.area,
                    latitude: req.body.latitude,
                    longitude: req.body.longitude,

                    street_name: req.body.street_name,
                    city_name: req.body.city_name,
                    state_name: req.body.state_name,
                    country_code: req.body.country_code,
                },

                    {
                        where: { id: req.body.outlet_id, user_id: user.data.user_id }
                    });
                if (updateOutletdata[0] === 1) {
                    response.successMsg(res, constant.OUTLET_UPDATED);
                } else {
                    return response.error(res, "Outlet Not Updated");
                }

            } else {
                return response.error(res, constant.OUTLET_NOTFOUND);
            }

        } catch (error) {
            return response.error(res, error.message);
        }
    }

    /**create outlet with logged-in merchant id */
    const createOutlet = async (req, res) => {


        try {
            const { user } = req;
            const validationResponse = validate.createOutlet(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }


            /**inserting outlet record */
            let newOutlet = await Outlet.create({
                outlet_name: req.body.outlet_name,
                postal_code: req.body.postal_code,
                address: req.body.address,
                phone_number: req.body.phone_number,
                brand_id: req.body.brand_id,
                //country_id: req.body.country_id,
                // state_id: req.body.stateId,
                city_id: req.body.city_id,
                //  area: req.body.area,
                latitude: req.body.latitude,
                longitude: req.body.longitude,
                status: true,
                is_deleted: false,
                user_id: user.data.user_id,

                street_name: req.body.street_name,
                city_name: req.body.city_name,
                state_name: req.body.state_name,
                country_code: req.body.country_code,


            });
            if (!newOutlet) {
                return response.error(res, constant.SERVER_ERROR);
            }

            return response.successMsg(res, constant.OUTLET_CREATED);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**get Coupons list on the basis of outletID with pagination */
    const outletCoupons = async ( req, res )=>{
        try {
            const validationResponse = validate.outletCoupon(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let couponCount = await Coupon.count({ where: { outlet_id: req.body.outletId , is_deleted: false } });
            let coupon = await Coupon.findAll({
                    where: { outlet_id: req.body.outletId , is_deleted: false },
                    include:{model: Category},
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            if(!coupon){
                return response.successDT(res, constant.COUPON_NOTFOUND, [], 0, 0);
            }
            coupon = coupon.map(Element => {
                return {
                    id: Element.id,
                    isCoupon: Element.is_coupon,
                    name: Element.coupon_name,
                    totalCoupons: Element.total_coupons,
                    type: Element.coupon_type,
                    couponImage: Element.coupon_image,
                    percentOff: Element.percent_off,
                    maxDiscount: Element.max_discount,
                    price: Element.amount,
                    perUser: Element.per_user,
                    couponCode: Element.coupon_code,
                    desc: Element.description,
                    totalCoupons: Element.total_coupons,
                    radius: Element.radius,
                    category: Element.Category.title,
                    validFrom: Element.valid_from,
                    validTill: Element.valid_till,
                    status: Element.status
                };
            });
            return response.successDT(res, constant.SUCCESS, coupon, couponCount, couponCount);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /**get Products list on the basis of outletID with pagination */
    const outletProducts = async ( req, res )=>{
        try {
            const validationResponse = validate.outletProduct(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let productCount = await Product.count({ where: { outlet_id: req.body.outletId , is_deleted: false } });
            let products = await Product.findAll({
                    where: { outlet_id: req.body.outletId , is_deleted: false },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            if(!products){
                return response.successDT(res, constant.PRODUCT_NOTFOUND, [], 0, 0);
            }
            let finalData = [];
              finalData = products.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.product_name,
                        productDescription: Element.product_desc,
                        productPrice: Element.price,
                        categoryId: Element.category_id,
                        productImage: Element.image,
                        phoneNumber: Element.phone_number,
                        createdAt: Element.createdAt,
                        status: Element.status ? 'Active' : 'InActive'
                    };
                });
            return response.successDT(res, constant.SUCCESS, finalData, productCount, productCount);     
        }catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }
    }

    /**Delete Outlet by id For Admin Portal  */
    const deleteOutlet = async (req, res) => {
        try {
            let updateRes =  await Outlet.update({
                is_deleted: true,
            },{where:{id: req.params.id }});
            console.log("DELETE:::",updateRes);
            if (!updateRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res,constant.OUTLET_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    return {
        allOutletList,
        createOutlet,
        updateoutlet,
        outletDetail,
        outletCoupons,
        outletProducts,
        getAllOutlets,
        searchOutlet,
        outletDetailforAdmin,
        deleteOutlet
    };
};

module.exports = OutletController;