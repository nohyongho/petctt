/** Model */
const Brand = require('../models/Brand');
const Outlet = require('../models/Outlet');
const Categories = require('../models/Categories');
const Product = require('../models/Products');
const MpTypeProduct = require('../models/MpTypeProduct');
const Country = require('../models/CountryList');
const State = require('../models/StateList');
const City = require('../models/CityList');
const TimeTable = require('../models/TimeTable');
/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/ProductsValidator');
const fs = require('fs');

const imageUpload = require('../services/imageUpload.service');

const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const Op = Sequelize.Op;

const path = require('path');


const ProductsController = () => {

    /**create produc with logged-in merchant id */
    const createProduct = async (req, res) => {

        const body = req.body;
        try {
            const { user } = req;
            let createProductType=[];
            const validationResponse = validate.createProduct(body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            /**inserting produc record */
            let newProduct = await Product.create({
                product_name: body.name,
                product_desc: body.description,
                category_id: body.categoryId,
                user_id: user.data.user_id,
                brand_id: body.brandId,
                outlet_id: body.outletId,
                price: body.price,
                image: await imageUpload.upload(body.image, 'admin/products',body.imageName),
                status: true,
                is_deleted: false,

            });
            if (!newProduct) {
                return response.error(res, constant.SERVER_ERROR);
            }
            // console.log('TESTING:::', body.productType)
            body.productType.map(typeProduct=>{
                createProductType.push({
                    product_id: newProduct.id,
                    type_product_id: typeProduct
                });
            });
            // console.log('Will be added ::',createProductType);
            let test =  await MpTypeProduct.bulkCreate(createProductType,{returning:true});
            // console.log("RETURING:::",test) 
            return response.successMsg(res, constant.PRODUCT_CREATED);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**get all registered outlets of specific brand(merchant's id)  */
    const merchantProductList = async (req, res) => {
        try {
            const { user } = req;
            const validationResponse = validate.merchantProductList(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let ProductsData = await Product.findAll({
                where: { user_id: user.data.user_id },
                include: [{
                    model: Brand,
                    required: true,
                    where: {
                        user_id: user.data.user_id
                    }
                }, { model: Outlet },
                { model: Categories, }],
                limit: parseInt(req.body.limit),
                offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
            });
            if (ProductsData.length != 0) {
                testData = ProductsData.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.product_name,
                        product_desc: Element.product_desc,
                        product_price: Element.price,
                        category_id: Element.category_id,
                        product_image: Element.image,
                        phoneNumber: Element.phone_number,
                        createdAt: Element.createdAt,
                        status: Element.status ? 'Active' : 'Blocked',


                        brand: {
                            id: Element.Brand.id,
                            name: Element.Brand.brand_name,
                            image: Element.Brand.image
                        },
                        outlet: {
                            id: Element.Outlet.id,
                            name: Element.Outlet.outlet_name,
                            phone_number: Element.Outlet.phone_number
                        }
                    };
                });
            } else {
                return response.error(res, constant.PRODUCT_NOTFOUND);
            }
            return response.successDT(res, constant.SUCCESS, testData, ProductsData.length);
        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all registered outlets products of specific brand(merchant's id)  */
    const outletProductList = async (req, res) => {
        try {
            const { user } = req;
            const validationResponse = validate.outletProductList(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let ProductsData = await
                Product.findAll({
                    where: [{
                        user_id: user.data.user_id
                    },
                    {
                        outlet_id: req.body.outletId
                    }],
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))

                });
                let finalData=[];
            if (ProductsData.length != 0) {
                finalData = ProductsData.map(Element => {
                    return {
                        id: Element.id,
                        name: Element.product_name,
                        productDescription: Element.product_desc,
                        productPrice: Element.price,
                        categoryId: Element.category_id,
                        productImage: Element.image,
                        phoneNumber: Element.phone_number,
                        createdAt: Element.createdAt,
                        status: Element.status ? 'Active' : 'InActive'
                    };
                });
            } else {
                return response.error(res, constant.PRODUCT_NOTFOUND);
            }
            let recordsTotal = finalData.length
            let recordsFiltered = finalData.length
            return response.successDT(res, constant.SUCCESS, finalData, recordsTotal, recordsFiltered);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all registered Poducts For Admin Portal  */
    const getAllProducts = async (req, res) => {
        try {
            
            const validationResponse = validate.getAllProducts(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let productCount= 0;
            if(req.body.filterType=='all'){
                productCount = await Product.count({where:{is_deleted:false}});
                queryClause = { 'is_deleted': false };
            }else{
                productCount = await Product.count({ where:{ outlet_id: `${ req.body.outletId }`, is_deleted: false } });
                queryClause = { 'outlet_id': `${req.body.outletId }`, 'is_deleted': false };
            }
            let ProductsData = await
                Product.findAll({
                    where: queryClause,
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))

                });
                if (ProductsData.length<1) {
                    return response.successDT(res, [],0,0);
                } 
                let finalData=[];
                    finalData = ProductsData.map(Element => {
                        return {
                            id: Element.id,
                            name: Element.product_name,
                            productDescription: Element.product_desc,
                            productPrice: Element.price,
                            categoryId: Element.category_id,
                            productImage: Element.image,
                            phoneNumber: Element.phone_number,
                            createdAt: Element.createdAt,
                            status: Element.status ? 'Active' : 'Inabctive'
                        };
                    });
            
                    return response.successDT(res, constant.SUCCESS, finalData, productCount, productCount);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    /**get all registered Poducts For Admin Portal  */
    const searchProducts = async (req, res) => {
        try {
            
            const validationResponse = validate.searchProduct(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let productCount= 0;
            productCount = await Product.count({ where:{ product_name: {[Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted: false } });
            let ProductsData = await
                Product.findAll({
                    where: { product_name: {[Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, is_deleted: false },
                    order: [['createdAt', 'desc']]
                });
                if (ProductsData.length<1) {
                    return response.successDT(res, [],0,0);
                } 
                let finalData=[];
                    finalData = ProductsData.map(Element => {
                        return {
                            id: Element.id,
                            name: Element.product_name,
                            productDescription: Element.product_desc,
                            productPrice: Element.price,
                            categoryId: Element.category_id,
                            productImage: Element.image,
                            phoneNumber: Element.phone_number,
                            createdAt: Element.createdAt,
                            status: Element.status ? 'Active' : 'Inabctive'
                        };
                    });
            
                    return response.successDT(res, constant.SUCCESS, finalData, productCount, productCount);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };
    
    /**create product by Admin */
    const addNewProduct = async (req, res) => {
        try {
            const { user } = req;
            const validationResponse = validate.createProduct(req.body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            /**inserting produc record */
            let newProduct = await Product.create({
                product_name: body.product_name,
                product_desc: body.product_desc,
                category_id: body.categories_id,
                user_id: user.data.user_id,
                brand_id: brand.id,
                outlet_id: body.outlet_id,
                price: body.price,
                image: await imageUpload.upload(body.image, 'product-images'),
                status: true,
                is_deleted: false,

            });
            if (!newProduct) {
                return response.error(res, constant.SERVER_ERROR);
            }
            return response.successMsg(res, constant.PRODUCT_CREATED);

        } catch (error) {
            console.log('Error:::', error);
            return response.error(res, error.message);
        }

    };

    /**get all & available, expired, pending Product list    */
    const allProductList = async (req, res) => {
        try {
            const { user } = req;
            const { type, status } = req.body;
            const bodyResposnse = validate.couponsList(req.body);
            if (bodyResposnse.status === false) {
                return response.error(res, bodyResposnse.msg);
            }
            let coupons;
            let brand = await Brand.findOne({ where: { user_id: user.data.user_id } });
            /**all coupons list */
            if (type === 'all') {
                coupons = await Coupon.findAll({
                    where: { brand_id: brand.id },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            }
            /**all available, expired or Pending Coupon list  */
            else if (type === 'other') {
                coupons = await Coupon.findAll({
                    where: { status: status, brand_id: brand.id },
                    order: [['createdAt', 'desc']],
                    limit: parseInt(req.body.limit),
                    offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
                });
            }
            let recordsTotal = 0;
            let recordsFiltered = 0;
            recordsTotal = coupons.length;
            recordsFiltered = coupons.length;
            coupons = coupons.map(Element => {
                return {
                    id: Element.id,
                    name: Element.coupon_name,
                    totalCoupons: Element.total_coupons,
                    type: Element.coupon_type,
                    validFrom: Element.valid_from,
                    validTill: Element.valid_till
                };
            });


            return response.successDT(res, constant.SUCCESS, coupons, recordsTotal, recordsFiltered);
        } catch (error) {
            console.log('Error is::', error);
            return response.error(res, error.message);
        }
    };

    /**Update outlet record */
    const updateproduct = async (req, res) => {
        try {

            const body = JSON.parse(req.body.updateProduct);
            const { user } = req;
            

            const validationResponse = validate.updateproduct(body);
            if (!validationResponse.status) {
                return response.bodyNotFound(res, validationResponse.msg);
            }
            let getproduct = await Product.findOne({ where: { id: body.product_id, user_id: user.data.user_id } });

            if (getproduct) {
                let updateproductdata = await Product.update({
                    product_name: body.product_name,
                    product_desc: body.product_desc,
                    category_id: body.category_id,
                    outlet_id: body.outlet_id,
                    price: body.price,
                }, {
                    where: { id: body.product_id, user_id: user.data.user_id }
                    });

                if (typeof req.file != 'undefined') {
                     const imagename = getproduct.image;

                    let imagearr = imagename.split("pImage/");



                    const imagedirpath = path.join(__dirname, '../public/models/images/products/') + imagearr[1]

                    console.log(imagedirpath)

                    fs.unlink(imagedirpath, (err) => {
                        if (err) {
                            console.error(err)
                            return
                        }

                        //file removed
                    });
                       await Product.update({

                        image: '/pImage/' + req.file.filename,
                    },

                        {
                            where: { id: body.product_id, user_id: user.data.user_id }
                        });

                }
                if (updateproductdata[0] === 1) {
                    response.successMsg(res, constant.PRODUCT_UPDATED);
                } else {
                    return response.error(res, "Product Not Updated");
                }

            } else {
                return response.error(res, constant.PRODUCT_NOTFOUND);
            }

        } catch (error) {
            return response.error(res, error.message);
        }
    }

    /**Delete Product by id For Admin Portal  */
    const deleteProduct = async (req, res) => {
        try {
            let deleteRes =  await Product.update({
                is_deleted: true,
            },{where:{id: req.params.id }});
            console.log("DELETE:::",deleteRes);
            if (!deleteRes[0]) {
                return response.error(res, constant.SERVER_ERROR );
            } 
            return response.successMsg(res, constant.PRODUCT_DELETED);

        } catch (error) {
            console.log("Error:::", error);
            return response.error(res, error.message);
        }
    };

    return {
        //  allOutletList,
        createProduct,
        merchantProductList,
        allProductList,
        outletProductList,
        updateproduct,
        getAllProducts,
        searchProducts,
        addNewProduct,
        deleteProduct

    };
};

module.exports = ProductsController;