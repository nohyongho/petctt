/** Model */
const FiatTransactions = require('../models/FiatTransactions');
const CryptoTransactions = require('../models/CryptoTransactions');


/** Library */
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

/** Helpers */
const response = require('../helper/response');
const constant = require('../constants/ConstantMessages');
const validate = require('../helper/validators/TransactionValidator');


const TransactionsController = () => {

    /**Get All Transactions for Admin portal */
    const getAllTransacions = async (req, res) => {
        try {
            const bodyResp = validate.transactionsList(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }
            let queryClause;
            let transactionCount=0;
            switch (req.body.filterType) {
                case 'all':
                    if(req.body.transactions=='fiat'){
                        
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: { soft_delete:false }
                        });
                        
                        queryClause = {  'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await fiatTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: { soft_delete:false }
                        });

                        queryClause = { 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await cryptoTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    break;
                case 'other':
                    if(!req.body.transactionType){return response.error(res, constant.TRANSACTION_TYPE)}
                    if(req.body.transactions=='fiat'){
                        
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: { txn_type: req.body.transactionType, soft_delete:false }
                        });
                        
                        queryClause = { 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await fiatTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: { txn_type: req.body.transactionType, soft_delete:false }
                        });

                        queryClause = { 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await cryptoTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    
                    break;

                default:
                    break;
            }

        } catch (error) {
            console.log('Error::', error);
            return response.error(res, error.message);
        }

    };

    /**Search From All Transactions  for Admin portal */
    const searchFromAllTransaction = async (req, res) => {
        try {

            const bodyResp = validate.searchAll(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }

            let queryClause;
            let transactionCount=0;
            
            switch (req.body.filterType) {
                case 'all':
                    if(req.body.transactions=='fiat'){
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: {id:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete:false }
                        });
                        
                        queryClause = { 'id':{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await searchFiatTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: {blockchain_address:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, soft_delete:false }
                        });

                        queryClause = { 'blockchain_address':{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await searchCryptoTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    break;
                case 'other':
                    if(!req.body.transactionType){return response.error(res, constant.TRANSACTION_TYPE)}
                    if(req.body.transactions=='fiat'){
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: { id: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%`  }, txn_type: req.body.transactionType, soft_delete:false }
                        });
                        
                        queryClause = {'id': { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%`  }, 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await searchFiatTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: { blockchain_address:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_type: req.body.transactionType, soft_delete:false }
                        });

                        queryClause = { 'blockchain_address':{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await searchCryptoTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    
                    break;

                default:
                    break;
            }

        } catch (error) {
            console.log('Error::', error);
            return response.error(res, error.message);
        }

    };
 
    /**Get Transactions by user Id for Admin portal */
    const getAllTransacionsOfUser = async (req, res) => {
        try {
            const bodyResp = validate.userTransactionsList(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }
            let queryClause;
            let transactionCount=0;
            switch (req.body.filterType) {
                case 'all':
                    if(req.body.transactions=='fiat'){
                        
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: { txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });
                        
                        queryClause = { 'txn_initiater_user_id': req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await fiatTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: {txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });

                        queryClause = {'txn_initiater_user_id': req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await cryptoTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    break;
                case 'other':
                    if(!req.body.transactionType){return response.error(res, constant.TRANSACTION_TYPE)}
                    if(req.body.transactions=='fiat'){
                        
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: {txn_initiater_user_id: req.body.userId,  txn_type: req.body.transactionType, soft_delete:false }
                        });
                        
                        queryClause = {'txn_initiater_user_id': req.body.userId, 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await fiatTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: { txn_initiater_user_id: req.body.userId, txn_type: req.body.transactionType, soft_delete:false }
                        });

                        queryClause = { 'txn_initiater_user_id': req.body.userId, 'txn_type': req.body.transactionType, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await cryptoTransaction(queryClause, req);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    
                    break;

                default:
                    break;
            }

        } catch (error) {
            console.log('Error::', error);
            return response.error(res, error.message);
        }

    };

    /**Search From All Transactions  for Admin portal */
    const searchFromTransactionByUser = async (req, res) => {
        try {

            const bodyResp = validate.searchUser(req.body);
            if (bodyResp.status === false) {
                return response.error(res, bodyResp.msg);
            }

            let queryClause;
            let transactionCount=0;
            
            switch (req.body.filterType) {
                case 'all':
                    if(req.body.transactions=='fiat'){
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: {id:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });
                        
                        queryClause = { 'id' :{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_initiater_user_id: req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await searchFiatTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: {blockchain_address:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });

                        queryClause = { 'blockchain_address':{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` },txn_initiater_user_id: req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await searchCryptoTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    break;
                case 'other':
                    if(!req.body.transactionType){return response.error(res, constant.TRANSACTION_TYPE)}
                    if(req.body.transactions=='fiat'){
                        
                        transactionCount = await 
                        FiatTransactions.count({ 
                            where: { id: { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_type: req.body.transactionType, txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });
                        
                        queryClause = {'id': { [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'txn_type': req.body.transactionType, txn_initiater_user_id: req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }
                        
                        let transactions = await searchFiatTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }else if(req.body.transactions=='crypto'){

                        transactionCount = await 
                        CryptoTransactions.count({ 
                            where: { blockchain_address:{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, txn_type: req.body.transactionType,txn_initiater_user_id: req.body.userId, soft_delete:false }
                        });

                        queryClause = { 'blockchain_address':{ [Op.like]: `%${req.body.searchValue.replace(/\s/g, '')}%` }, 'txn_type': req.body.transactionType,txn_initiater_user_id: req.body.userId, 'soft_delete': false };
                        
                        if(!queryClause){
                            return response.successDT(res, constant.NO_RECORD, [],0,0 );
                        }

                        let transactions = await searchCryptoTransaction(queryClause);
                        return response.successDT(res, constant.SUCCESS, transactions,transactionCount,transactionCount );
                    
                    }
                    
                    break;

                default:
                    break;
            }

        } catch (error) {
            console.log('Error::', error);
            return response.error(res, error.message);
        }

    };

    return {

        getAllTransacions,
        searchFromAllTransaction,
        getAllTransacionsOfUser,
        searchFromTransactionByUser
        
    };

};

module.exports = TransactionsController;






async function fiatTransaction(queryClause, req) {
    let transactions = await FiatTransactions.findAll({
        where: queryClause,
        order: [['createdAt', 'desc']],
        limit: parseInt(req.body.limit),
        offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
    });
    transactions = transactions.map(Element => {
        return {
            id: Element.id,
            AmountKrw: parseInt(Element.amount_krw),
            FeeKrw: parseInt(Element.fee_krw),
            comments: Element.comments,
            status: Element.status,
            Txtype: Element.txn_type,
            softDelete: Element.soft_delete,
            createdAt: Element.createdAt,
            updatedAt: Element.updatedAt,
        };
    });
    return transactions;
}

async function cryptoTransaction(queryClause, req) {
    let transactions = await CryptoTransactions.findAll({
        where: queryClause,
        order: [['createdAt', 'desc']],
        limit: parseInt(req.body.limit),
        offset: parseInt(req.body.limit) * (parseInt(req.body.page - 1))
    });
    transactions = transactions.map(Element => {
        return {
            id: Element.id,
            TxId: Element.blockchain_txn_id,
            blockChainAddress: Element.blockchain_address,
            AmountCrpto: Element.amount_crypto,
            FeeCrypto: Element.fee_crypto,
            comments: Element.comments,
            status: Element.status,
            Txtype: Element.txn_type,
            softDelete: Element.soft_delete,
            createdAt: Element.createdAt,
            updatedAt: Element.updatedAt,
        };
    });
    return transactions;
}

async function searchFiatTransaction(queryClause) {
    let transactions = await FiatTransactions.findAll({
        where: queryClause,
        order: [['createdAt', 'desc']]
    });
    transactions = transactions.map(Element => {
        return {
            id: Element.id,
            AmountKrw: parseInt(Element.amount_krw),
            FeeKrw: parseInt(Element.fee_krw),
            comments: Element.comments,
            status: Element.status,
            Txtype: Element.txn_type,
            softDelete: Element.soft_delete,
            createdAt: Element.createdAt,
            updatedAt: Element.updatedAt,
        };
    });
    return transactions;
}

async function searchCryptoTransaction(queryClause) {
    let transactions = await CryptoTransactions.findAll({
        where: queryClause,
        order: [['createdAt', 'desc']],
    });
    transactions = transactions.map(Element => {
        return {
            id: Element.id,
            TxId: Element.blockchain_txn_id,
            blockChainAddress: Element.blockchain_address,
            AmountCrpto: Element.amount_crypto,
            FeeCrypto: Element.fee_crypto,
            comments: Element.comments,
            status: Element.status,
            Txtype: Element.txn_type,
            softDelete: Element.soft_delete,
            createdAt: Element.createdAt,
            updatedAt: Element.updatedAt,
        };
    });
    return transactions;
}