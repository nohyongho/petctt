module.exports = {
    apps: [
        {
            name: 'CTT-AB-PROD 3082',
            script: "./bin/www",
            autorestart: true,
            max_restarts: 10,
            watch: false,
            max_memory_restart: '1G',
            env_production: {
              NODE_ENV: 'production',
              PORT: 3082,
            }
        }
    ]
};
