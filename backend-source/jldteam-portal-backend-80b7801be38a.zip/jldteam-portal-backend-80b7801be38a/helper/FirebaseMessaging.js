const constants = require('../constants/commonConstants');
var FirebaseMsg = require('fcm-node');
var firebaseMsg = new FirebaseMsg(constants.commonConstants.serverKey);

/*
Android In App notification utility.
TAK
*/

function FirebaseMessaging(sendTo, title, message, jsonData) {

    this.sendTo = sendTo;
    this.title = title;
    this.message = message;
    this.jsonData = jsonData;


    this.send = () => {
        console.log("called already")
        var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
            to: this.sendTo,
            collapse_key: 'your_collapse_key',

            notification: {
                title: this.title,
                body: this.message,
                data: this.jsonData
            },

            data: { //you can send only notification or only data(or include both)
                title : this.title,
                body: this.body,
                message : this.message,
                data : this.jsonData
            }
        };

        firebaseMsg.send(message, function (err, response) {
            if (err) {
                console.log("Something has gone wrong!");
            } else {
                console.log("Successfully sent with response: ", response);
            }
        });
    }

}

module.exports = FirebaseMessaging;