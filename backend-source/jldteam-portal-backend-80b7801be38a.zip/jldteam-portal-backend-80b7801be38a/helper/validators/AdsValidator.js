const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {

    paginationBody: (body)=>{
        const response = validator(body,{
            limit: JOI.number().required(),
            page: JOI.number().required(),
            adsType: JOI.string().optional().allow(''),
            status: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
        });
        return response;
    },
    searchBody: (body)=>{
        const response = validator(body,{
            searchValue:JOI.string().required()
        });
        return response;
    },

    seenAds: (body)=>{
        const response = validator(body,{
            adId: JOI.number().required(),
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },

};