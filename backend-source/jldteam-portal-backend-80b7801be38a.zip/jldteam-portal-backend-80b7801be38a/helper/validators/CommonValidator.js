const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {
   brandList: (body) => {
       const response = validator(body, {
        limit: JOI.number().required(),
        page: JOI.number().required(),
        filterType: JOI.string().required(),
        categoryId: JOI.number().optional().allow(''),
        })
        return response;
   },
   getsubCategoriesProduct: (body) => {
        const response = validator(body, {
        //    brand_id: JOI.number().required(),

        });
        return response;
    },
    redeemedCoupons: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    searchBrand: (body)=>{
        const response = validator(body,{
            searchValue:JOI.string().required()
        });
        return response;
    },
    searchBody: (body)=>{
        const response = validator(body,{
            searchValue:JOI.string().required()
        });
        return response;
    },
    brandOutlet: (body) => {
        const response = validator(body, {
            brandId: JOI.number().required(),
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    categoryBody: (body) =>{
        const response = validator(body,{
            title: JOI.string().required(),
            parentId: JOI.number().required(),
            image: JOI.string().required() ,
            imageName: JOI.string().required()
        });
        return response;
    },
    paginationBody: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    productTypeBody: (body) =>{
        const response = validator(body,{
            title: JOI.string().required(),
            image: JOI.string().required() ,
            imageName: JOI.string().required()
        });
        return response;
    },
    updateGeneralConfigRecord: (body) =>{
        const response = validator(body,{
            configValue: JOI.number().required(),
        });
        return response;
    },
    updateCoinConfigRecord: (body) =>{
        const response = validator(body,{
            rewardCnvrsnPrcnt: JOI.number().required(),
            krwToCryptoFeePrcnt: JOI.number().required(),
            minRewardConvert: JOI.number().required(),
            minKrwToConvert: JOI.number().required(),
        });
        return response;
    },
};