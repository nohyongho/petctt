const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {

    couponsList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            outletId: JOI.number().required(),
            type: JOI.string().required(),
            status: JOI.string().optional().allow('')
        });
        return response;
    },

    getCoupons: (body)=>{
        const response = validator(body,{
            limit: JOI.number().required(),
            page: JOI.number().required(),
            filterType: JOI.string().required(),
            status: JOI.string().optional().allow(''),
            outletId: JOI.number().optional().allow(''),
            categoryId: JOI.number().optional().allow('')
        })
        return response;
    },

    couponsListByUser:(body)=>{
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            userId: JOI.number().required(),
        });
        return response;
    },

    searchCouponByUser: (body) => {
        const response = validator(body, {
            userId: JOI.number().required(),
            searchValue: JOI.string().optional().allow(''),
        });
        return response;
    },

    searchCouponByName: (body) => {
        const response = validator(body, {
            searchValue: JOI.string().required(),
        });
        return response;
    },

    redeemedCoupons: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },

    getCouponsBody: (body) => {
        const response = validator(body, {
            current_lat: JOI.number().required(),
            current_long: JOI.number().required(),
        });
        return response;
    },

    categoriesByBrandId: (body) => {
        const response = validator(body, {
            //   brand_id: JOI.number().required(),

        });
        return response;
    },
    
    getsubCategoriesProduct: (body) => {
        const response = validator(body, {
            //    brand_id: JOI.number().required(),

        });
        return response;
    },

    collectCouponBody: (body) => {
        const response = validator(body, {
            collected_coupon: JOI.object().keys({
                coupon_id: JOI.number().required(),
                coupon_name: JOI.string().required(),
                coupon_type: JOI.string().required(),
                coupon_image: JOI.string().optional().allow(null),
                brand_id: JOI.number().required(),
                brand_name: JOI.string().required(),
                category_id: JOI.number().required(),
                outlet_id: JOI.number().required(),
                outlet_name: JOI.string().required(),
                coupon_code_id: JOI.number().required(),
                coupon_code: JOI.string().required(),
                hash: JOI.string().required(),
                longitude: JOI.number().required(),
                latitude: JOI.number().required()
            }),
        });
        return response;
    },

    createCouponBody: (body) => {
        const response = validator(body, {
            name: JOI.string().max(100).required(),
            maximumDiscount: JOI.number().required(),
            percentOff: JOI.number().required(),
            quantity: JOI.number().required(),
            radius: JOI.number().required(),
            perUser: JOI.number().required(),
            code: JOI.string().required(),
            description: JOI.string().required(),
            validFrom: JOI.string().required(),
            validTill: JOI.string().required(), 
            outletId: JOI.number().required(),
            image: JOI.string().required(),
            brandId: JOI.number().required(),
        });
        return response;
    },

    updatecouponBody: (body) => {
        const response = validator(body, {

            coupon_id: JOI.number().required(),
            coupon_name: JOI.string().max(100).required(),
            description: JOI.string().required(),
            total_coupons: JOI.number().required(),

            coupon_code: JOI.string().required(),

            outlet_id: JOI.number().required(),
            percent_off: JOI.number().required(),
            amount: JOI.number().required(),
            radius: JOI.string().required(),
            // type: JOI.string().required(),
            valid_from: JOI.string().required(),
            valid_till: JOI.string().required(),
            per_user: JOI.number().required(),

            outlet_id: JOI.number().required(),
            category_id: JOI.number().required(),





        });
        return response;
    }
    
};