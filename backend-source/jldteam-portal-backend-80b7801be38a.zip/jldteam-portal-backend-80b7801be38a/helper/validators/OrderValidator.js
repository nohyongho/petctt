const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {   
    orderList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            orderType: JOI.string().required(),
            outletId: JOI.number().required()
        });
        return response;
    },
    orderListByUser: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            orderType: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
            userId: JOI.number().required()
        });
        return response;
    },
    searchOrderByUSer: (body) => {
        const response = validator(body, {
            userId: JOI.number().required(),
            searchValue: JOI.string().optional().allow(''),
        });
        return response;
    },
    getAllorders: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            outletId: JOI.number().optional().allow(''),
            orderType: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
        });
        return response;
    },
    searchOrders: (body) => {
        const response = validator(body, {
            searchValue: JOI.string().optional().allow(''),
        });
        return response;
    },
};