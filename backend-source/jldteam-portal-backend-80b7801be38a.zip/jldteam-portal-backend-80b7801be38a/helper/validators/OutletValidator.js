const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {
    createOutlet: (body) => {
        const response = validator(body, {
            outlet_name: JOI.string().min(3).max(100).required(),
            postal_code: JOI.string().required(),
            address: JOI.string().required(),
            phone_number: JOI.string().required(),
            brand_id: JOI.number().required(),
           // country_id: JOI.number().required(),
          //  stateId: JOI.number().required(),
          city_id: JOI.number().required(),
          //  area: JOI.number().required(),
            latitude: JOI.number().required(),
            longitude: JOI.number().required(),
           // altitude: JOI.number().required(),
            //timeTable: JOI.array().required(),
           // user_id: JOI.number().required(),
           state_name:JOI.string().optional(),

           street_name:JOI.string().optional(),
           city_name:JOI.string().optional(),
           
           country_code:JOI.string().optional(),



        });
        return response;
    },


    updateoutlet: (body) => {
        const response = validator(body, {
            outlet_id: JOI.number().required(),
            outlet_name: JOI.string().min(3).max(100).required(),
            postal_code: JOI.string().required(),
            address: JOI.string().required(),
            phone_number: JOI.string().required(),
            brand_id: JOI.number().required(),
           // country_id: JOI.number().required(),
          //  stateId: JOI.number().required(),
          city_id: JOI.number().required(),
          //  area: JOI.number().required(),
            latitude: JOI.number().required(),
            longitude: JOI.number().required(),
           // altitude: JOI.number().required(),
            //timeTable: JOI.array().required(),
           // user_id: JOI.number().required(),
           state_name:JOI.string().optional(),

           street_name:JOI.string().optional(),
           city_name:JOI.string().optional(),
           
           country_code:JOI.string().optional(),



        });
        return response;
    },


    outletList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    allOutlets: (body) => {
        const response = validator(body, {
         limit: JOI.number().required(),
         page: JOI.number().required(),
         filterType: JOI.string().required(),
         brandId: JOI.number().optional().allow(''),
         });
         return response;
    },
    searchOutlet: (body)=>{
        const response = validator(body,{
            searchValue:JOI.string().required()
        });
        return response;
    },
    outletCoupon: (body)=>{
        const response = validator(body, {
            outletId: JOI.number().required(),
            limit: JOI.number().required(),
            page: JOI.number().required()
        });
        return response;
    },
    outletProduct: (body)=>{
        const response = validator(body, {
            outletId: JOI.number().required(),
            limit: JOI.number().required(),
            page: JOI.number().required()
        });
        return response;
    }
};