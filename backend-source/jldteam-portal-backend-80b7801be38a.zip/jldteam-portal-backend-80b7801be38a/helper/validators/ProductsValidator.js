const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {

    createProduct: (body) => {
        const response = validator(body, {
            name: JOI.string().min(3).max(100).required(),
            categoryId: JOI.number().required(),
            outletId: JOI.number().required(),
            price: JOI.number().required(),
            brandId: JOI.number().required(),
            description:JOI.string().optional().allow(''),
            image: JOI.string().required(),
            imageName: JOI.string().required(),
            productType: JOI.array().required()
        });
        return response;
    },

    updateproduct: (body) => {
        const response = validator(body, {
            product_id: JOI.number().required(),
            product_name: JOI.string().min(3).max(100).required(),
            category_id: JOI.number().required(),
            outlet_id: JOI.number().required(),
            price: JOI.number().required(),
            product_desc:JOI.string().optional().allow(''),
        });
        return response;
    },

    merchantProductList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },

    outletProductList: (body)=>{

        const response = validator(body, {
            outletId: JOI.number().required(),
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
      

    },
    getAllProducts: (body)=>{
        const response = validator(body,{
            filterType: JOI.string().required(),
            outletId: JOI.number().optional().allow(''),
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    searchProduct: (body)=>{
        const response = validator(body,{
            searchValue:JOI.string().required()
        });
        return response;
    },
       

    
    


};