const JOI = require('joi');
const validator = require('../JoiValidationResponse');

module.exports = {
    userTransactionsList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            userId: JOI.number().required(),
            transactionType: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
            transactions: JOI.string().required()
        });
        return response;
    },
    transactionsList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
            transactionType: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
            transactions: JOI.string().required()
        });
        return response;
    },
    searchAll: (body) => {
        const response = validator(body, {
            searchValue: JOI.string().optional().allow(''),
            transactionType: JOI.string().optional().allow(''),
            filterType: JOI.string().required(),
            transactions: JOI.string().required()
        });
        return response;
    },
    searchUser: (body) => {
        const response = validator(body, {
            searchValue: JOI.string().optional().allow(''),
            transactionType: JOI.string().optional().allow(''),
            userId: JOI.number().required(),
            filterType: JOI.string().required(),
            transactions: JOI.string().required()
        });
        return response;
    },
         
};