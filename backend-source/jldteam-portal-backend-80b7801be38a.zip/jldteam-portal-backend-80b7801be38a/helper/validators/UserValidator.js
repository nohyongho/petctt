const JOI = require('joi');
const validator = require('../JoiValidationResponse');


module.exports = {
    allUsersList: (body) => {
        const response = validator(body, {
            filterType: JOI.string().required(),
            limit: JOI.number().required(),
            page: JOI.number().required(),
            filterBy: JOI.string().required()
        });
        return response;
    },
    searchUsers: (body) => {
        const response = validator(body, {
            searchType: JOI.string().required(),
            searchValue: JOI.string().optional().allow(''),
        });
        return response;
    },
    filterUsers: (body) => {
        const response = validator(body, {
            type: JOI.string().required(),
            length: JOI.number().required(),
            start: JOI.number().required(),
            orderBy: JOI.string().required(),
            order: JOI.string().required(),
            startDate: JOI.string().required(),
            endDate: JOI.string().required(),
            userStatus: JOI.string().optional().allow(''),
            verified: JOI.string().optional().allow('')
        });
        return response;
    },
    userDetail:(body) => {
        const response = validator(body, {
            userId: JOI.number().required(),
        })
        return response;
    },
    userFind:(body) => {
        const response = validator(body, {
            type: JOI.string().required(),
            email: JOI.string().required(),
        })
        return response;
    },
    updateUserStatus: (body) => {
        const response = validator(body, {
            status: JOI.string().required()
        })
        return response;
    },
    outletUsersList: (body) => {
        const response = validator(body, {
            limit: JOI.number().required(),
            page: JOI.number().required(),
        });
        return response;
    },
    changePassword: (body) => {
        const response = validator(body, {
            newPassword: JOI.string().required(),
            oldPassword: JOI.string().required(),
        });
        return response;
    },
};