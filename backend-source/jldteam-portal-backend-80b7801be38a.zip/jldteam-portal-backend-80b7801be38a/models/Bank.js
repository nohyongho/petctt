const Sequelize = require('sequelize');
const sequelize = require('../config/database');

const tableName = 'tblbank';

class Bank extends Sequelize.Model { };

 Bank.init({
    Bkcode: {
        type: Sequelize.INTEGER,
        allowNull:true
    },
    Mid: {
        type: Sequelize.STRING(50)
    },
    Bkacctno: {
        type: Sequelize.STRING(64),
        allowNull: true,
    },
    Bkname:{
        type:Sequelize.STRING(32),
    },
    Bkdate: {
        type: Sequelize.DATEONLY,
    },
    Bktime: {
        type: Sequelize.TIME,
    },
    Bkjukyo:{
        type:Sequelize.STRING(60),
    },
    Bkcontent:{
        type:Sequelize.STRING(60),
      
    },
    Bketc:{
        type:Sequelize.STRING(60),
      
    },
    Bkinput:{
        type:Sequelize.INTEGER,
      
    },
    Bkoutput:{
        type:Sequelize.INTEGER,
      
    },
    Bkjango:{
        type:Sequelize.INTEGER,
      
    },
    Bkxferdatetime:{
        type:Sequelize.DATE,
      
    },

}, {
    sequelize,
    tableName
});


module.exports = Bank;