const Sequelize = require('sequelize');
const sequelize = require('../config/database');

const Country = require('./CountryList');
const Category = require('./Categories');
const User = require('./User');
const Outlet = require('./Outlet');


const tableName = 'brand';

class Brand extends Sequelize.Model { };

 Brand.init({
    brand_name: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true,
        validate: {
            len: [1, 50]
        },
    },
    image: {
        type: Sequelize.STRING(255)
    },
    phone_number: {
        type: Sequelize.STRING(15),
        allowNull: true,
        unique: true,
        validate: {
            len: [8, 15]
        },
    },
    category_id: {
        type: Sequelize.INTEGER,
    },
    postal_code:{
        type:Sequelize.STRING,
       
    },
    address:{
        type:Sequelize.STRING,
      
    },
    is_deleted:{
        type:Sequelize.BOOLEAN,
      
    },

}, {
    sequelize,
    tableName
});

/** Category Join */
Brand.belongsTo(Category, { foreignKey: 'category_id' });

/** user Join */
Brand.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Brand, { foreignKey: 'user_id' });

/** Country Join */
Brand.belongsTo(Country, { foreignKey: 'country_id' });

/**Outlet Join */
Brand.hasMany(Outlet, { foreignKey: 'brand_id' });
Outlet.belongsTo(Brand, { foreignKey: 'brand_id' });

module.exports = Brand;