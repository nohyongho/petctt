const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const UsersCryptoWallet = require('./UsersCryptoWallet');
const Coin = require('./Coin');


const tableName = 'transaction_crypto';

class CryptoTransaction extends Sequelize.Model { };

CryptoTransaction.init({
    blockchain_txn_id: {
        type: Sequelize.STRING
    },
    blockchain_address: {
        type: Sequelize.STRING
    },
    amount_crypto: {
        type: Sequelize.DOUBLE,
    },
    fee_crypto: {
        type: Sequelize.DOUBLE
    },
    comments: {
        type: Sequelize.STRING(200)
    },
    status: {
        type: Sequelize.ENUM('PENDING', 'CANCELLED', 'CONFIRMED', 'CANCELLED_BY_USER'),
    },
    txn_type:{
        type:Sequelize.ENUM('WALLET_TOPUP', 'TRANSFER', 'REFUND', 'ORDER', 'COUPON_BUY', 'FIAT_TO_CRYPTO_EXCHANGE', 'CRYPTO_TO_FIAT_EXCHANGE')
    },
    soft_delete:{
        type:Sequelize.BOOLEAN,
    }

}, {
    sequelize,
    tableName
});

CryptoTransaction.hasMany(CryptoTransaction, {
    foreignKey: 'referrence_txn_id',
    as: 'Children',
    allowNull:true 
});

/** User Join */
CryptoTransaction.belongsTo(User, { foreignKey: 'txn_initiater_user_id' });
User.hasMany(CryptoTransaction, { foreignKey: 'txn_initiater_user_id' });

/** UsersCryptoWallet Join For Debiter */
CryptoTransaction.hasMany(UsersCryptoWallet, { foreignKey: 'debit_wallet_id' });
UsersCryptoWallet.belongsTo(CryptoTransaction, { foreignKey: 'debit_wallet_id' });

/** UsersCryptoWallet Join  For Crediter*/
CryptoTransaction.belongsTo(UsersCryptoWallet, { foreignKey: 'credit_wallet_id' });
UsersCryptoWallet.hasMany(CryptoTransaction, { foreignKey: 'credit_wallet_id' });

/** Bank Join */
CryptoTransaction.belongsTo(Coin, { foreignKey: 'coin_id' });
Coin.hasMany(CryptoTransaction, { foreignKey: 'coin_id' });

module.exports = CryptoTransaction;