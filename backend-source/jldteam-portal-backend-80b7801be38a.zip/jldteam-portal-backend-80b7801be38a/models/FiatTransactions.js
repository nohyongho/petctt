const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const UsersFiatWallet = require('./UsersFiatWallet');
const Bank = require('./Bank');


const tableName = 'transaction_fiat';

class FiatTransaction extends Sequelize.Model { };

 FiatTransaction.init({
    amount_krw: {
        type: Sequelize.DOUBLE
    },
    fee_krw: {
        type: Sequelize.DOUBLE
    },
    status: {
        type: Sequelize.ENUM('PENDING', 'CANCELLED', 'CONFIRMED', 'CANCELLED_BY_USER'),
    },
    txn_type:{
        type:Sequelize.ENUM('WALLET_TOPUP', 'TRANSFER', 'REFUND', 'ORDER', 'COUPON_BUY', 'FIAT_TO_CRYPTO_EXCHANGE', 'CRYPTO_TO_FIAT_EXCHANGE')
    },
    comments: {
        type: Sequelize.STRING(200),
    }, 
    bankda_ref_id: {
        type: Sequelize.INTEGER,
    },
    soft_delete:{
        type:Sequelize.BOOLEAN,
    }

}, {
    sequelize,
    tableName
});

FiatTransaction.hasMany(FiatTransaction, {
    foreignKey: 'referrence_txn_id',
    as: 'Children',
    allowNull:true 
});

/** User Join */
FiatTransaction.belongsTo(User, { foreignKey: 'txn_initiater_user_id' });
User.hasMany(FiatTransaction, { foreignKey: 'txn_initiater_user_id' });

/** UsersFiatWallet Join For Debiter */
FiatTransaction.hasMany(UsersFiatWallet, { foreignKey: 'debit_wallet_id' });
UsersFiatWallet.belongsTo(FiatTransaction, { foreignKey: 'debit_wallet_id' });

/** UsersFiatWallet Join  For Crediter*/
FiatTransaction.belongsTo(UsersFiatWallet, { foreignKey: 'credit_wallet_id' });
UsersFiatWallet.hasMany(FiatTransaction, { foreignKey: 'credit_wallet_id' });

/** Bank Join */
FiatTransaction.hasMany(Bank, { foreignKey: 'Bkid' });
Bank.belongsTo(FiatTransaction, { foreignKey: 'Bkid' });

module.exports = FiatTransaction;