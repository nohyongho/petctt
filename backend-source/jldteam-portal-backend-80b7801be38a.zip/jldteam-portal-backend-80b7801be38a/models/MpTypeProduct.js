const Sequelize = require('sequelize');
const sequelize = require('../config/database');

const Products = require('./Products');
const ProductType = require('./ProductType');


const tableName = 'mp_type_products';

const MpTypeProduct = sequelize.define('MpTypeProduct', {}, {
    tableName
});

/** Coupon Join */
MpTypeProduct.belongsTo(Products, {
    foreignKey: 'product_id'
});
Products.hasMany(MpTypeProduct, {
    foreignKey: 'product_id'
});

/** Outlet Join */
MpTypeProduct.belongsTo(ProductType, {
    foreignKey: 'type_product_id'
});
ProductType.hasMany(MpTypeProduct, {
    foreignKey: 'type_product_id'
});

module.exports = MpTypeProduct;