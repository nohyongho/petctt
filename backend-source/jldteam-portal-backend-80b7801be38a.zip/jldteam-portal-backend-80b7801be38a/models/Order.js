const Sequelize = require('sequelize');
const sequelize = require('../config/database');

const Outlet = require('./Outlet');
const User = require('./User');

const tableName = 'orders';

class Order extends Sequelize.Model { };

Order.init({
    total: {
        type: Sequelize.DECIMAL(8,2),
        allowNull: false,
        defaultValue: 0.0
    },
    sub_total: {
        type: Sequelize.DECIMAL(8,2),
        allowNull: false,
        defaultValue: 0.0
    },
    vat: {
        type: Sequelize.DECIMAL(8,2),
        allowNull: false,
        defaultValue: 0.0
    },
    coupon_code: {
        type: Sequelize.STRING(30),
        allowNull: true,
    },
    coupon_discount: {
        type: Sequelize.DECIMAL(8,2),
        allowNull: false,
        defaultValue: 0.0
    },
    payment_status: {
        type: Sequelize.ENUM('PENDING','COMPLETE')
    },
    payment_type: {
        type: Sequelize.ENUM('COD','CARD','CRYPTO','CASH')
    },
    order_type: {
        type: Sequelize.ENUM('DINE_IN','DELIVERY')
    },
    status: {
        type: Sequelize.ENUM('PENDING', 'CANCELLED_BY_USER', 'CANCELLED_BY_MERCHANT', 'DELIVERED', 'PREPARING', 'ON_THE_WAY')
    },
    order_state_time_change: {
        type: Sequelize.DATE                                    ,
        allowNull: true
    },
    cancel_charges: {
        type: Sequelize.DECIMAL(8,2),
        allowNull: false,
        defaultValue: 0.0
      
    },
    user_address_id: {
        type: Sequelize.INTEGER,
      
    },
    item_quantity: {
        type: Sequelize.INTEGER,
      
    },
    instructions: {
        type: Sequelize.STRING(),
      
    },
    cancel_reason:{
        type:Sequelize.STRING,
    },
    waiting_time:{
       type: Sequelize.INTEGER 
    },
    soft_delete:{
        type: Sequelize.BOOLEAN,
        allowNull:false,
        defaultValue:false
    }
}, {
    sequelize,
    tableName
});



/** Country Join */
Order.belongsTo(Outlet, { foreignKey: 'outlet_id' });
Outlet.hasMany(Order, { foreignKey: 'outlet_id' });

/** User Join */
Order.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Order, { foreignKey: 'user_id' });




module.exports = Order;