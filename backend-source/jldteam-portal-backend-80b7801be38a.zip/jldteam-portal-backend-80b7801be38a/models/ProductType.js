const Sequelize = require('sequelize');
const sequelize = require('../config/database');

const tableName = 'type_products';

class ProductType extends Sequelize.Model { };

ProductType.init( {
    type_title: {
        type: Sequelize.STRING,
    },
    image:{
        type:Sequelize.STRING
    },
    is_deleted:{
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    }

}, {
    sequelize,
    tableName
});

module.exports = ProductType;