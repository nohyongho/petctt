const express = require('express');
const router = express.Router();

const AdsController = require('../controllers/AdsController');
const authGaurd = require('../middleware/authGaurd');



/**get All Ads route with authentication */
router.post ('/getAllAds', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().getAllAds(req,res);
});
/**get All searched Ads route with authentication */
router.post ('/searchAds', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().searchAds(req,res);
});
/**get Ad Detail route with authentication */
router.get ('/getAdDetail/:id', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().getAdDetail(req,res);
});

/**get seen ads by ad Id route with authentication */
router.post ('/userSeenAdByAdId', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().userSeenAdByAdId(req,res);
});

/**Update Status route with authentication */
router.put ('/updateAdStatus/:id', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().updateAdStatus(req,res);
});
/**Update Percentage route with authentication */
router.put ('/updatePercentage/:id', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().updatePercentage(req,res);
});
/**Delete Ad route with authentication */
router.delete('/deleteAd/:id', authGaurd.authenticatePrivate, function (req, res) {
    AdsController().deleteAd(req,res);
});
module.exports = router;