var express = require('express');
var router = express.Router();
const AuthController = require('../controllers/AuthController');
const authGaurd = require('../middleware/authGaurd');

/** Library */
const multer = require('multer');
const path = require('path');


/** File upload module */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {

    
    cb(null, path.join(__dirname, '../public/models/images/brands/'));
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.split('.');
    const type = fileName[1];
    cb(null, `brand-${Date.now()}.${type}`);
  }
});


const upload = multer({
  fileFilter: (req, file, cb) => {

    const mimetype = String(file.mimetype).trim();

    if (mimetype === 'image/png' || mimetype === 'image/jpg' || mimetype === 'image/jpeg') {
      cb(null, true);

    } else {
      req.fileValidationError = 'goes wrong on the mimetype';
      return cb(null, false, new Error('goes wrong on the mimetype'));
    }

  },
  storage: storage
});



router.get('/', function (req, res, next) {
  res.send('Invalid Path');
});


router.post('/register', function (req, res, next) {
  AuthController().register(req, res);
});
// router.post('/createbrand',upload.single('brand_logo'), function (req, res, next) {
//   AuthController().brandcreation(req, res);
// });
router.post('/createbrand',upload.single('brand_logo'), function (req, res, next) {
  AuthController().brandcreation(req, res);
});


router.post('/login', function (req, res, next) {
  AuthController().login(req, res);
});

router.post('/resetPassword', authGaurd.authenticatePrivate, function (req, res, next) {
  AuthController().resetPassword(req, res);
});

router.post('/updateProfile', authGaurd.authenticatePrivate, upload.single('file'), function (req, res, next) {
  AuthController().updateProfile(req, res);
});

router.get('/verifyEmail/:code', function (req, res, next) {
  AuthController().verifyEmail(req, res);
});

router.post('/createOutletUser',authGaurd.authenticatePrivate, function (req, res, next) {
  AuthController().createOutletUser(req, res);
});
/**Sending verification code on email */
router.post('/forgotpassSendCode', function (req, res, next) {
  AuthController().sendCode(req, res);
});
/**#verify and reset new password */
router.post('/verifyAndResetPassword', function (req, res, next) {
  AuthController().verifyAndResetPassword(req, res);
});

router.get('/logout',authGaurd.authenticatePrivate, function (req, res, next) {
  AuthController().logout(req, res);
});
module.exports = router;
