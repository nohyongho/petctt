var express = require('express');
var router = express.Router();
const CommonController = require('../controllers/CommonController');
const authGaurd = require('../middleware/authGaurd');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('Try another route');
});

router.get('/getCountryList', function (req, res, next) {
    CommonController().getCountryList(req, res);
});


/** GET states list  */
router.get('/statesList/:countryId', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().statesList(req, res);
});

/**Get cities List */
// router.get('/citiesList/:stateId', authGaurd.authenticatePrivate, function (req, res, next) {
//     CommonController().citiesList(req, res);
// });

router.get('/citiesList/:countryId', authGaurd.authenticatePrivate, function (req, res, next) {
        CommonController().citiesList(req, res);
});

/**Get General Configurations List */
router.get('/getGeneralConfig', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getGeneralConfig(req, res);
});

/**update General Config */
router.put('/updateGeneralConfig/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().updateGeneralConfig(req, res);
});

/**Get ITC Coin */
router.get('/getCoin', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getCoin(req, res);
});

/**Get updateCoin attributes */
router.put('/updateCoin/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().updateCoin(req, res);
});

router.get('/getCoinsList', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getCoinsList(req, res);
});

/* GET users listing. */
router.get('/allOnDashboard', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().allOnDashboard(req, res);
});

/* GET users listing. */
router.get('/collectedCouponsCountry', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().collectedCouponsCountry(req, res);
});

/* GET users listing. */
router.get('/countryStateCities', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().countryStateCities(req, res);
});

/* GET users brand listing. */
router.get('/getMyBrand', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getMyBrand(req, res);
});
/* GET users brand listing. */
router.get('/getBrands', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getBrands(req, res);
});

/* allBrandList */
router.post('/allBrandList', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().allBrandList(req, res);
});

/* seachBrands */
router.post('/searchBrands', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().searchBrands(req, res);
});

/* GET getCategories listing. */
router.get('/getCategories', function (req, res, next) {
    CommonController().getCategories(req, res);
});

/* GET getsubCategories listing. */
router.get('/getsubCategories', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getsubCategories(req, res);
});

/* GET getsubCategories listing for products creation against a brand id */
router.get('/getsubCategoriesProduct/:brandId', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getsubCategoriesProduct(req, res);
});

/* GET getCurrencies listing. */
router.get('/getCurrencies', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getCurrencies(req, res);
});


/* GET getOutlets listing. */
router.get('/getOutlets', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getOutlets(req, res);
});

/* GET allOutletList For Admin Portal. */
router.get('/allOutletList', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().allOutletList(req, res);
});
/* GET visitorsCountryMap listing. */
router.get('/visitorsCountryMap', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().visitorsCountryMap(req, res);
});

/* GET pieChartCouponStatus listing. */
router.get('/pieChartCouponStatus', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().pieChartCouponStatus(req, res);
});

/* GET pieChartCouponCategory listing. */
router.get('/pieChartCouponCategory', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().pieChartCouponCategory(req, res);
});

/* GET categoriesByBrandId listing. */
router.get('/categoriesByBrand', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().categoriesByBrand(req, res);
});

/* GET categoriesByBrandIdUser listing. */
router.get('/categoriesByBrandIdUser', authGaurd.authenticatePrivate, function (req, res, next) {
        CommonController().categoriesByBrandIdUser(req, res);
});
/* GET categoriesByBrandIdUser listing. */
router.post('/getAllCategory', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getAllCategory(req, res);
});
router.get('/getCategoryDetail/:id',authGaurd.authenticatePrivate,function(req,res,next){
    CommonController().getCategoryDetail(req,res);
})
router.post('/searchCategory', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().searchCategory(req, res);
});
router.post('/createCategory', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().createCategory(req, res);
});
/* GET accountsDetail listing. */ 
router.get('/accountsDetail', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().accountsDetail(req, res);
});
/* GET adminDashboardSummary listing. */
router.get('/adminDashboardSummary', function (req, res, next) {
    CommonController().adminDashboardSummary(req, res);
});

/* GET redeemedCouponDetail listing. */
router.post('/redeemedCouponDetail', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().redeemedCouponDetail(req, res);
});

/**
 * For Mercahnt Dashboard 
 */
router.get('/recentCollectedCoupons', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentCollectedCoupons(req, res);
  });
router.get('/topFiveCouponHunters', authGaurd.authenticatePrivate, function (req, res, next) {
CommonController().topFiveCouponHunters(req, res);
});
/* GET Recent Delivery Orders. */
router.get('/recentDeliveryOrders', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentDeliveryOrders(req, res);
});
/* GET Recent Dini-in Orders */
router.get('/recentDineInOrders', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentDineInOrders(req, res);
});
/* GET Recent Dini-in Orders */
router.get('/allBrandsOnDashboard/:brandId', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().allBrandsOnDashboard(req, res);
});
/**
 * END
 */

/**
 * For Admin Dashboard
 */
router.get('/recentHuntedCoupons', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentHuntedCoupons(req, res);
  });
router.get('/topFiveHunters', authGaurd.authenticatePrivate, function (req, res, next) {
CommonController().topFiveHunters(req, res);
});
/* GET Recent Delivery Orders. */
router.get('/recentDelivery', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentDelivery(req, res);
});
/* GET Recent Dini-in Orders */
router.get('/recentDineIn', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().recentDineIn(req, res);
});

/** Route For Getting Sums and Total of Brands their outlets, coupons,products etc */
router.get('/brandsAccordionData', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().brandsAccordionData(req, res);
});

/** Route For Getting Sums and Total of Brands their outlets, coupons,products etc */
router.get('/brandDetails/:brandId', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().brandDetails(req, res);
});

/** outlet list by brand id and  */
router.post('/brandOutlets', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().brandOutlets(req, res);
});

/** outlet list by brand id and  */
router.get('/outletsAccordionData', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().outletsAccordionData(req, res);
});

/** outlet list by brand id and  */
router.get('/getOutletByBrandId/:brandId', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getOutletByBrandId(req, res);
});

/**All outlet list for Admin Portal*/
router.get('/getOutletsList', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getOutletsList(req, res);
});

/**All Product Types list for Admin Portal*/
router.get('/productTypeList', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().productTypeList(req, res);
});

/**All Product Types list with Pagination for Admin Portal*/
router.post('/getAllProductTypes', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().getAllProductTypes(req, res);
});
/**search Product Types for Admin Portal*/
router.post('/searchProductTypes', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().searchProductTypes(req, res);
});
/**create Product Type for Admin Portal*/
router.post('/createProductType', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().createProductType(req, res);
});

/**Delete Product Types for Admin Portal*/
router.delete('/deleteProductType/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().deleteProductType(req, res);
});
/**delete category  for Admin Portal*/
router.delete('/deleteCategory/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().deleteCategory(req, res);
});

/**delete Brand  for Admin Portal*/
router.delete('/deleteBrand/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    CommonController().deleteBrand(req, res);
});

/**
 * END
 */

module.exports = router;
