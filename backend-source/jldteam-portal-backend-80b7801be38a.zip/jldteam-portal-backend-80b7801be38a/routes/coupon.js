var express = require('express');
var router = express.Router();
const CouponController = require('../controllers/CouponController');
const authGaurd = require('../middleware/authGaurd');



/** Library */
const multer = require('multer');
const path = require('path');

/** File upload module */
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
  
      
      cb(null, path.join(__dirname, '../public/models/images/coupons/'));
    },
    filename: (req, file, cb) => {
      const fileName = file.originalname.split('.');
      const type = fileName[1];
      cb(null, `coupon-${Date.now()}.${type}`);
    }
  });
  
  
  const upload = multer({
    fileFilter: (req, file, cb) => {
  
      const mimetype = String(file.mimetype).trim();
  
      if (mimetype === 'image/png' || mimetype === 'image/jpg' || mimetype === 'image/jpeg') {
        cb(null, true);
  
      } else {
        req.fileValidationError = 'goes wrong on the mimetype';
        return cb(null, false, new Error('goes wrong on the mimetype'));
      }
  
    },
    storage: storage
  });






router.get('/', function (req, res, next) {
  res.send('Invalid Path');
});

router.post('/getCoupons', authGaurd.authenticatePrivate, function (req, res, next) {
    CouponController().getCoupons(req, res);
});

router.post('/getCouponList', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().getCouponList(req, res);
});

router.post('/searchCouponByName', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().searchCouponByName(req, res);
});

router.post('/collectCoupon', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().collectCoupon(req, res);
});

router.post('/getCollectedCouponHistory', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().getCollectedCouponHistory(req, res);
});

router.get('/getCategories', function (req, res, next) {
  CouponController().getCategories(req, res);
});


router.get('/getBrandByCategoryId/:categoryId', function (req, res, next) {
  CouponController().getBrandByCategoryId(req, res);
});


router.post('/allCouponList', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().allCouponList(req, res);
});

router.post('/getCouponListByUser', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().getCouponListByUser(req, res);
});

router.post('/searchCouponsByUser', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().searchCouponsByUser(req, res);
});

router.post('/createCoupon',  upload.single('coupon_image'),authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().createCoupon(req, res);
});

router.post('/updateCoupon',  upload.single('coupon_image'),authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().updateCoupon(req, res);
});

router.get('/getCouponDetail/:id', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().getCouponDetail(req, res);
});

/**Get Coupon Detail Request for Admin Portal  */
router.get('/couponDetail/:couponId', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().couponDetail(req, res);
});

router.get('/activeCouponSummary', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().activeCouponSummary(req, res);
});

/**delete Coupon  for Admin Portal*/
router.delete('/deleteCoupon/:id', authGaurd.authenticatePrivate, function (req, res, next) {
  CouponController().deleteCoupon(req, res);
});

module.exports = router;
