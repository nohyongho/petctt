var express = require('express');
var router = express.Router();
const OrderController = require('../controllers/OrderController');
const authGaurd = require('../middleware/authGaurd');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('Try another route');
});

/* GET order listing. */
router.post('/allOrderList', authGaurd.authenticatePrivate, function (req, res, next) {
    OrderController().allOrderList(req, res);
});
/* GET orders list on the basis of user_id. */
router.post('/ordersByUser', authGaurd.authenticatePrivate, function (req, res, next) {
    OrderController().ordersByUser(req, res);
});
/* seach orders list on the basis of user_id. */
router.post('/searchOrdersByUser', authGaurd.authenticatePrivate, function (req, res, next) {
    OrderController().searchOrdersByUser(req, res);
});
/**Get All Order list For Admin */
router.post('/getAllOrdersList', authGaurd.authenticatePrivate, function (req, res, next) {
    OrderController().getAllOrdersList(req, res);
});
/**Search Order list For Admin */
router.post('/searchOrders', authGaurd.authenticatePrivate, function (req, res, next) {
    OrderController().searchOrders(req, res);
});
module.exports = router;
