var express = require('express');
var router = express.Router();
const OutletController = require('../controllers/OutletController');
const authGaurd = require('../middleware/authGaurd');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('Try another route');
});

/* GET users listing. */
router.post('/getAllOutlets', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().getAllOutlets(req, res);
});
/* GET users listing. */
router.post('/searchOutlet', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().searchOutlet(req, res);
});
/* GET users listing. */
router.get('/outletDetailforAdmin/:outletId', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().outletDetailforAdmin(req, res);
});
/* GET users listing. */
router.post('/allOutletList', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().allOutletList(req, res);
});

/* Create Outlet */
router.post('/createOutlet', authGaurd.authenticatePrivate, function (req, res, next) {
    console.log(req)
    OutletController().createOutlet(req, res);
});


/* Update Outlet */
router.post('/updateOutlet', authGaurd.authenticatePrivate, function (req, res, next) {
    console.log(req)
    OutletController().updateoutlet(req, res);
});


router.get('/outletDetail/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().outletDetail(req, res);
});

router.post('/outletCoupons', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().outletCoupons(req, res);
});

router.post('/outletProducts', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().outletProducts(req, res);
});

/**delete Outlet  for Admin Portal*/
router.delete('/deleteOutlet/:id', authGaurd.authenticatePrivate, function (req, res, next) {
    OutletController().deleteOutlet(req, res);
});

module.exports = router;
