var express = require('express');
var router = express.Router();
const ProductsController = require('../controllers/ProductsController');
const authGaurd = require('../middleware/authGaurd');

/** Library */
const multer = require('multer');
const path = require('path');

/** File upload module */
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
  
      
      cb(null, path.join(__dirname, '../public/models/images/products/'));
    },
    filename: (req, file, cb) => {
      const fileName = file.originalname.split('.');
      const type = fileName[1];
      cb(null, `product-${Date.now()}.${type}`);
    }
  });
  
  
  const upload = multer({
    fileFilter: (req, file, cb) => {
  
      const mimetype = String(file.mimetype).trim();
  
      if (mimetype === 'image/png' || mimetype === 'image/jpg' || mimetype === 'image/jpeg') {
        cb(null, true);
  
      } else {
        req.fileValidationError = 'goes wrong on the mimetype';
        return cb(null, false, new Error('goes wrong on the mimetype'));
      }
  
    },
    storage: storage
  });

/* Create Merchant's Product. */
router.post('/createProduct', authGaurd.authenticatePrivate,  function (req, res, next) {
    //req.setHeader("Content-Type", "application/x-www-form-urlencoded");
    // console.log(req.body)

    ProductsController().createProduct(req, res);
});

/* Update Merchant's Product. */
router.post('/updateProduct', authGaurd.authenticatePrivate,  upload.single('image'), function (req, res, next) {
  //req.setHeader("Content-Type", "application/x-www-form-urlencoded");
  console.log(req.body)

  ProductsController().updateproduct(req, res);
});

/* GET Merchant's product listing. */
router.post('/merchantProductList', authGaurd.authenticatePrivate, function (req, res, next) {
  ProductsController().merchantProductList(req, res);
});
/* GET Merchant's product listing. */
router.post('/outletProductList', authGaurd.authenticatePrivate, function (req, res, next) {
  ProductsController().outletProductList(req, res);
});

/**Get All Product List For Admin Portal */
router.post('/getAllProducts',authGaurd.authenticatePrivate,function(req,res,next){
  ProductsController().getAllProducts(req,res);
});
/**Get SEarched Product List For Admin Portal */
router.post('/searchProducts',authGaurd.authenticatePrivate,function(req,res,next){
  ProductsController().searchProducts(req,res);
});
/**delete Coupon  for Admin Portal*/
router.delete('/deleteProduct/:id', authGaurd.authenticatePrivate, function (req, res, next) {
  ProductsController().deleteProduct(req, res);
});





module.exports = router;
