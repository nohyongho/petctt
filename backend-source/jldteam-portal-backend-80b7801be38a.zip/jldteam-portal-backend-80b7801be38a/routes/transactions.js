var express = require('express');
var router = express.Router();
const TransactionsController = require('../controllers/TransactionsController');
const authGaurd = require('../middleware/authGaurd');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('Try another route');
});

/* GET All Transacions listing. */
router.post('/getAllTransacions', authGaurd.authenticatePrivate, function (req, res, next) {
    TransactionsController().getAllTransacions(req, res);
});

/* search Transaction for Admin */
router.post('/searchFromAllTransaction', authGaurd.authenticatePrivate, function (req, res, next) {
    TransactionsController().searchFromAllTransaction(req, res);
});

/*Get Transactions by user Id for Admin Portal */
router.post('/getAllTransacionsOfUser', authGaurd.authenticatePrivate, function (req, res, next) {
    TransactionsController().getAllTransacionsOfUser(req, res);
});

/**search transaction by user Id For Admin */
router.post('/searchFromTransactionByUser', authGaurd.authenticatePrivate, function (req, res, next) {
    TransactionsController().searchFromTransactionByUser(req, res);
});

module.exports = router;
