var express = require('express');
var router = express.Router();
const WalletController = require('../controllers/WalletController');
const authGaurd = require('../middleware/authGaurd');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('Try another route');
});

/* transferItcFromAdminToUser */
router.post('/transferItcFromAdminToUser', authGaurd.authenticatePrivate, function (req, res, next) {
    WalletController().transferItcFromAdminToUser(req, res);
});

/* transferItcFromAdminToUser */
router.get('/getBalances', authGaurd.authenticatePrivate, function (req, res, next) {
    WalletController().getBalances(req, res);
});
module.exports = router;
