// ============================================
// 👤 User Model
// ============================================
const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  // ID로 사용자 찾기
  static async findById(id) {
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE id = ? AND is_active = true',
      [id]
    );
    return rows[0] || null;
  }

  // 이메일로 사용자 찾기
  static async findByEmail(email) {
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    return rows[0] || null;
  }

  // 소셜 provider로 사용자 찾기
  static async findByProvider(provider, providerId) {
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE provider = ? AND provider_id = ?',
      [provider, providerId]
    );
    return rows[0] || null;
  }

  // 새 사용자 생성 (이메일/비밀번호)
  static async createLocal({ email, password, nickname }) {
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(password, salt);

    const [result] = await pool.query(
      `INSERT INTO users (email, password, nickname, provider) 
       VALUES (?, ?, ?, 'local')`,
      [email, hashedPassword, nickname]
    );

    return this.findById(result.insertId);
  }

  // 소셜 로그인 사용자 생성/업데이트
  static async findOrCreateSocial({ provider, providerId, email, nickname, profileImage }) {
    // 1) provider + providerId로 먼저 찾기
    let user = await this.findByProvider(provider, providerId);
    
    if (user) {
      // 기존 유저 — 프로필 업데이트
      await pool.query(
        `UPDATE users SET nickname = ?, profile_image = ?, updated_at = NOW() 
         WHERE id = ?`,
        [nickname || user.nickname, profileImage || user.profile_image, user.id]
      );
      return this.findById(user.id);
    }

    // 2) 같은 이메일로 된 local 계정이 있으면 연동
    if (email) {
      user = await this.findByEmail(email);
      if (user) {
        await pool.query(
          `UPDATE users SET provider = ?, provider_id = ?, profile_image = ?, updated_at = NOW()
           WHERE id = ?`,
          [provider, providerId, profileImage || user.profile_image, user.id]
        );
        return this.findById(user.id);
      }
    }

    // 3) 신규 생성
    const [result] = await pool.query(
      `INSERT INTO users (email, nickname, profile_image, provider, provider_id)
       VALUES (?, ?, ?, ?, ?)`,
      [email, nickname, profileImage, provider, providerId]
    );

    return this.findById(result.insertId);
  }

  // 비밀번호 검증
  static async verifyPassword(plainPassword, hashedPassword) {
    return bcrypt.compare(plainPassword, hashedPassword);
  }

  // 사용자 정보 (비밀번호 제외) 반환
  static sanitize(user) {
    if (!user) return null;
    const { password, ...safeUser } = user;
    return safeUser;
  }
}

module.exports = User;
