// config/passport.js
// Passport 전략 설정 - Google, Kakao, Naver

const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const KakaoStrategy = require('passport-kakao').Strategy;
const NaverStrategy = require('passport-naver-v2').Strategy;
const pool = require('../server/db');

// DB에서 사용자 찾기 or 생성
async function findOrCreateUser({ provider, providerId, email, nickname, name, profileImage }) {
  const conn = pool.promise();
  try {
    // 1. 같은 provider + provider_id로 검색
    const [existing] = await conn.query(
      'SELECT * FROM users WHERE provider = ? AND provider_id = ?',
      [provider, providerId]
    );
    if (existing.length > 0) {
      await conn.query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [existing[0].id]);
      console.log(`✅ 기존 사용자 로그인: ${email} (${provider})`);
      return existing[0];
    }

    // 2. 같은 이메일로 검색 (다른 소셜로 가입한 경우)
    if (email) {
      const [byEmail] = await conn.query('SELECT * FROM users WHERE email = ?', [email]);
      if (byEmail.length > 0) {
        // 기존 계정에 provider 정보 추가
        await conn.query(
          'UPDATE users SET provider = ?, provider_id = ?, profile_image = COALESCE(profile_image, ?), last_login_at = NOW() WHERE id = ?',
          [provider, providerId, profileImage, byEmail[0].id]
        );
        console.log(`✅ 기존 이메일 연결: ${email} → ${provider}`);
        return byEmail[0];
      }
    }

    // 3. 새 사용자 생성
    const [result] = await conn.query(
      'INSERT INTO users (email, nickname, name, profile_image, provider, provider_id, last_login_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [email, nickname || (email ? email.split('@')[0] : `user_${Date.now()}`), name, profileImage, provider, providerId]
    );
    const [newUser] = await conn.query('SELECT * FROM users WHERE id = ?', [result.insertId]);
    console.log(`✅ 새 사용자 생성: ${email} (${provider})`);
    return newUser[0];
  } catch (err) {
    console.error(`❌ findOrCreateUser 에러 (${provider}):`, err.message);
    throw err;
  }
}

// ===== Google Strategy =====
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  console.log('📌 Google OAuth 설정:', {
    clientID: process.env.GOOGLE_CLIENT_ID.substring(0, 20) + '...',
    callbackURL: process.env.GOOGLE_CALLBACK_URL,
  });

  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL,
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      console.log('🔍 Google profile received:', profile.id, profile.emails?.[0]?.value);
      const user = await findOrCreateUser({
        provider: 'google',
        providerId: profile.id,
        email: profile.emails?.[0]?.value,
        nickname: profile.displayName,
        name: profile.displayName,
        profileImage: profile.photos?.[0]?.value,
      });
      done(null, user);
    } catch (err) {
      console.error('❌ Google strategy error:', err);
      done(err, null);
    }
  }));
} else {
  console.warn('⚠️ Google OAuth: CLIENT_ID 또는 CLIENT_SECRET 누락');
}

// ===== Kakao Strategy =====
if (process.env.KAKAO_CLIENT_ID) {
  console.log('📌 Kakao OAuth 설정:', {
    clientID: process.env.KAKAO_CLIENT_ID.substring(0, 15) + '...',
    callbackURL: process.env.KAKAO_CALLBACK_URL,
  });

  passport.use(new KakaoStrategy({
    clientID: process.env.KAKAO_CLIENT_ID,
    clientSecret: process.env.KAKAO_CLIENT_SECRET || '',
    callbackURL: process.env.KAKAO_CALLBACK_URL,
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      console.log('🔍 Kakao profile received:', profile.id, profile._json?.kakao_account?.email);
      const kakaoAccount = profile._json?.kakao_account || {};
      const user = await findOrCreateUser({
        provider: 'kakao',
        providerId: String(profile.id),
        email: kakaoAccount.email || null,
        nickname: profile.displayName || kakaoAccount.profile?.nickname,
        name: kakaoAccount.profile?.nickname || profile.displayName,
        profileImage: kakaoAccount.profile?.profile_image_url,
      });
      done(null, user);
    } catch (err) {
      console.error('❌ Kakao strategy error:', err);
      done(err, null);
    }
  }));
} else {
  console.warn('⚠️ Kakao OAuth: CLIENT_ID 누락');
}

// ===== Naver Strategy =====
if (process.env.NAVER_CLIENT_ID && process.env.NAVER_CLIENT_SECRET) {
  console.log('📌 Naver OAuth 설정:', {
    clientID: process.env.NAVER_CLIENT_ID.substring(0, 10) + '...',
    callbackURL: process.env.NAVER_CALLBACK_URL,
  });

  passport.use(new NaverStrategy({
    clientID: process.env.NAVER_CLIENT_ID,
    clientSecret: process.env.NAVER_CLIENT_SECRET,
    callbackURL: process.env.NAVER_CALLBACK_URL,
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      console.log('🔍 Naver profile received:', profile.id, profile.email);
      const user = await findOrCreateUser({
        provider: 'naver',
        providerId: profile.id,
        email: profile.email || profile._json?.email,
        nickname: profile.nickname || profile.displayName,
        name: profile.name || profile.displayName,
        profileImage: profile.profileImage || profile._json?.profile_image,
      });
      done(null, user);
    } catch (err) {
      console.error('❌ Naver strategy error:', err);
      done(err, null);
    }
  }));
} else {
  console.warn('⚠️ Naver OAuth: CLIENT_ID 또는 CLIENT_SECRET 누락');
}

module.exports = passport;
